// import 'dart:convert';
//
//
// import 'package:flutter/material.dart';
// import 'dart:io';
//
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart' as http;
//
// import 'login.dart';
//
// class Registration extends StatefulWidget {
//   const Registration({Key? key}) : super(key: key);
//
//   @override
//   _RegistrationState createState() => _RegistrationState();
// }
//
// class _RegistrationState extends State<Registration> {
//   TextEditingController dateInputController = TextEditingController();
//   final TextEditingController nameController = TextEditingController();
//   // final TextEditingController lnameController = TextEditingController();
//   final TextEditingController placeController = TextEditingController();
//   final TextEditingController postController = TextEditingController();
//   final TextEditingController pinController = TextEditingController();
//   final TextEditingController phoneController = TextEditingController();
//   // final TextEditingController emailController = TextEditingController();
//   final TextEditingController usernameController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();
//   String? selectedGender;
//   final _formKey = GlobalKey<FormState>(); // Add a global key for the form
//
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         backgroundColor: Colors.white,
//         appBar: AppBar(
//           title: const Text("SentriLock App"),
//         ),
//         body: SafeArea(
//             child:Form(
//                 key: _formKey, child: SingleChildScrollView(
//                 child: Column(children: [
//                   const Padding(
//                     padding: EdgeInsets.all(8.0),
//                     child: Align(
//                       alignment: Alignment.center,
//                       child: Text(
//                         "Register",
//                         style: TextStyle(
//                           fontSize: 25,
//                           fontWeight: FontWeight.bold,
//                           color: Colors.blue,
//                         ),
//                       ),
//                     ),
//                   ),
//
//                   Padding(
//                     padding: EdgeInsets.all(8.0),
//                     child: TextFormField(
//                       controller: nameController,
//                       decoration: InputDecoration(
//                         fillColor: Colors.white,
//                         border: OutlineInputBorder(),
//                         hintText: "Name",
//                       ),
//                       validator: (value) {
//                         if (value!.isEmpty) {
//                           return 'Please enter your Full Name';
//                         }
//                         return null; // Return null if the input is valid
//                       },
//                     ),
//                   ),
//                   // Padding(
//                   //   padding: EdgeInsets.all(8.0),
//                   //   child: TextFormField(
//                   //     controller: lnameController,
//                   //     decoration: InputDecoration(
//                   //       fillColor: Colors.white,
//                   //       border: OutlineInputBorder(),
//                   //       hintText: "Last Name",
//                   //     ),
//                   //     validator: (value) {
//                   //       if (value!.isEmpty) {
//                   //         return 'Please enter your last name';
//                   //       }
//                   //       return null; // Return null if the input is valid
//                   //     },
//                   //   ),
//                   // ),
//                   Padding(
//                     padding: EdgeInsets.all(8.0),
//                     child: TextFormField(
//                       controller: phoneController,
//                       decoration: InputDecoration(
//                         fillColor: Colors.white,
//                         border: OutlineInputBorder(),
//                         hintText: "Phone",
//                       ),
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.all(8.0),
//                     child: TextFormField(
//                       controller: placeController,
//                       decoration: InputDecoration(
//                         fillColor: Colors.white,
//                         border: OutlineInputBorder(),
//                         hintText: "Place",
//                       ),
//                       validator: (value) {
//                         if (value!.isEmpty) {
//                           return 'Please enter your Place';
//                         }
//                         return null; // Return null if the input is valid
//                       },
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.all(8.0),
//                     child: TextFormField(
//                       controller: postController,
//                       decoration: InputDecoration(
//                         fillColor: Colors.white,
//                         border: OutlineInputBorder(),
//                         hintText: "Post",
//                       ),
//                       validator: (value) {
//                         if (value!.isEmpty) {
//                           return 'Please enter your Post';
//                         }
//                         return null; // Return null if the input is valid
//                       },
//                     ),
//                   ),
//
//                   Padding(
//                     padding: EdgeInsets.all(8.0),
//                     child: TextFormField(
//                       controller: pinController,
//                       decoration: InputDecoration(
//                         fillColor: Colors.white,
//                         border: OutlineInputBorder(),
//                         hintText: "Pin",
//                       ),
//                       validator: (value) {
//                         if (value!.isEmpty) {
//                           return 'Please enter your Pin';
//                         }
//                         return null; // Return null if the input is valid
//                       },
//                     ),
//                   ),
//                   // Padding(
//                   //   padding: EdgeInsets.all(8.0),
//                   //   child: TextFormField(
//                   //     controller: phoneController,
//                   //     decoration: InputDecoration(
//                   //       fillColor: Colors.white,
//                   //       border: OutlineInputBorder(),
//                   //       hintText: "Phone",
//                   //     ),
//                   //   ),
//                   // ),
//                   // Padding(
//                   //     padding: EdgeInsets.all(8.0),
//                   //     child: TextFormField(
//                   //         controller: emailController,
//                   //         decoration: InputDecoration(
//                   //           fillColor: Colors.white,
//                   //           border: OutlineInputBorder(),
//                   //           hintText: "Email",
//                   //         ))),
//                   Padding(
//                       padding: EdgeInsets.all(8.0),
//                       child: TextFormField(
//                         controller: usernameController,
//                         decoration: InputDecoration(
//                           fillColor: Colors.white,
//                           border: OutlineInputBorder(),
//                           hintText: "Username",
//                         ),
//                         validator: (value) {
//                           if (value!.isEmpty) {
//                             return 'Please enter your username';
//                           }
//                           return null; // Return null if the input is valid
//                         },
//                       )),
//                   Padding(
//                       padding: EdgeInsets.all(8.0),
//                       child: TextFormField(
//                         controller: passwordController,
//                         decoration: InputDecoration(
//                           fillColor: Colors.white,
//                           border: OutlineInputBorder(),
//                           hintText: "Password",
//                         ),
//                         validator: (value) {
//                           if (value!.isEmpty) {
//                             return 'Please enter your password';
//                           }
//                           return null; // Return null if the input is valid
//                         },)), Padding(
//                     padding: EdgeInsets.all(8.0),
//                     child: ElevatedButton.icon(
//                       onPressed: () async {
//                         if(!_formKey.currentState!.validate())
//                         {print("vvvvvvvvvvvvvvvvvvv");}
//                         else{
//                           final sh = await SharedPreferences.getInstance();
//                           String Name=nameController.text.toString();
//                           String phone=phoneController.text.toString();
//                           // String lname=lnameController.text.toString();
//                           String place=placeController.text.toString();
//                           String post=postController.text.toString();
//                           String pin=pinController.text.toString();
//                           // String phone=phoneController.text.toString();
//                           // String email=emailController.text.toString();
//                           String uname=usernameController.text.toString();
//                           String password=passwordController.text.toString();
//
//
//                           String url = sh.getString("url").toString();
//                           print("okkkkkkkkkkkkkkkkk");
//                           var data = await http.post(
//                               Uri.parse(url+"registration"),
//                               body: {'name':Name,
//                                   'phone':phone,
//                                 // 'lname':lname,
//                                   'place':place,
//                                 'post':post,
//                                 'pin':pin,
//                                 // 'phone':phone,
//                                 // 'email':email,
//                                 'uname':uname,
//                                 'password':password,
//                                 'lid':sh.getString("lid").toString(),
//                               });
//                           var jasondata = json.decode(data.body);
//                           String status=jasondata['task'].toString();
//                           if(status=="valid")
//                           {
//
//                             Navigator.push(context,
//                                 MaterialPageRoute(builder: (context) => login()));
//
//                           }
//                           else{
//                             print("error");
//
//                           }}
//
//                       },
//                       icon: Icon(Icons.send),
//                       label: Text('Submit'),
//                       style: ButtonStyle(
//                         backgroundColor: MaterialStateProperty.all<Color>(
//                           Color(0xFF6ADC50), // Use a proper color value (e.g., Hex or RGB)
//                         ),
//                       ),
//                     ),
//                   )])))
//         ));
//   }
// }








// import 'dart:convert';
// import 'dart:io';
//
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart' as http;
//
// import 'login.dart';
//
// class Registration extends StatefulWidget {
//   const Registration({Key? key}) : super(key: key);
//
//   @override
//   _RegistrationState createState() => _RegistrationState();
// }
//
// class _RegistrationState extends State<Registration> {
//   TextEditingController dateInputController = TextEditingController();
//   final TextEditingController nameController = TextEditingController();
//   final TextEditingController placeController = TextEditingController();
//   final TextEditingController postController = TextEditingController();
//   final TextEditingController pinController = TextEditingController();
//   final TextEditingController phoneController = TextEditingController();
//   final TextEditingController usernameController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();
//   String? selectedGender;
//   final _formKey = GlobalKey<FormState>();
//
//   XFile? _image;
//   final ImagePicker _picker = ImagePicker();
//
//   Future<void> _imgFromCamera() async {
//     try {
//       XFile? image = await _picker.pickImage(
//         source: ImageSource.camera,
//         imageQuality: 50,
//       );
//       if (image != null) {
//         setState(() {
//           _image = image;
//         });
//       } else {
//         print('No image selected from camera.');
//       }
//     } catch (e) {
//       print('Camera error: $e');
//     }
//   }
//
//   Future<void> _imgFromGallery() async {
//     try {
//       XFile? image = await _picker.pickImage(
//         source: ImageSource.gallery,
//         imageQuality: 50,
//       );
//       if (image != null) {
//         setState(() {
//           _image = image;
//         });
//       } else {
//         print('No image selected from gallery.');
//       }
//     } catch (e) {
//       print('Gallery error: $e');
//     }
//   }
//
//   void _showPicker(BuildContext context) {
//     showModalBottomSheet(
//       context: context,
//       builder: (BuildContext bc) {
//         return SafeArea(
//           child: Wrap(
//             children: <Widget>[
//               ListTile(
//                 leading: const Icon(Icons.photo_library),
//                 title: const Text('Photo Library'),
//                 onTap: () {
//                   _imgFromGallery();
//                   Navigator.of(context).pop();
//                 },
//               ),
//               ListTile(
//                 leading: const Icon(Icons.photo_camera),
//                 title: const Text('Camera'),
//                 onTap: () {
//                   _imgFromCamera();
//                   Navigator.of(context).pop();
//                 },
//               ),
//             ],
//           ),
//         );
//       },
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         backgroundColor: Colors.white,
//         appBar: AppBar(
//           title: const Text("SentriLock App"),
//         ),
//         body: SafeArea(
//           child: Form(
//             key: _formKey,
//             child: SingleChildScrollView(
//               child: Column(
//                 children: [
//                   const Padding(
//                     padding: EdgeInsets.all(8.0),
//                     child: Align(
//                       alignment: Alignment.center,
//                       child: Text(
//                         "Register",
//                         style: TextStyle(
//                           fontSize: 25,
//                           fontWeight: FontWeight.bold,
//                           color: Colors.blue,
//                         ),
//                       ),
//                     ),
//                   ),
//                   GestureDetector(
//                     onTap: () => _showPicker(context),
//                     child: CircleAvatar(
//                       radius: 55,
//                       backgroundColor: const Color(0xffdbd8cd),
//                       child: _image != null
//                           ? ClipRRect(
//                         borderRadius: BorderRadius.circular(50),
//                         child: Image.file(
//                           File(_image!.path),
//                           width: 100,
//                           height: 100,
//                           fit: BoxFit.cover,
//                         ),
//                       )
//                           : Container(
//                         decoration: BoxDecoration(
//                           color: Colors.grey[200],
//                           borderRadius: BorderRadius.circular(50),
//                         ),
//                         width: 100,
//                         height: 100,
//                         child: const Icon(
//                           Icons.camera_alt,
//                           color: Colors.grey,
//                         ),
//                       ),
//                     ),
//                   ),
//                   Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: TextFormField(
//                       controller: nameController,
//                       decoration: const InputDecoration(
//                         fillColor: Colors.white,
//                         border: OutlineInputBorder(),
//                         hintText: "Name",
//                       ),
//                       validator: (value) {
//                         if (value!.isEmpty) {
//                           return 'Please enter your Full Name';
//                         }
//                         return null;
//                       },
//                     ),
//                   ),
//                   Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: TextFormField(
//                       controller: phoneController,
//                       decoration: const InputDecoration(
//                         fillColor: Colors.white,
//                         border: OutlineInputBorder(),
//                         hintText: "Phone",
//                       ),
//                     ),
//                   ),
//                   Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: TextFormField(
//                       controller: placeController,
//                       decoration: const InputDecoration(
//                         fillColor: Colors.white,
//                         border: OutlineInputBorder(),
//                         hintText: "Place",
//                       ),
//                       validator: (value) {
//                         if (value!.isEmpty) {
//                           return 'Please enter your Place';
//                         }
//                         return null;
//                       },
//                     ),
//                   ),
//                   Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: TextFormField(
//                       controller: postController,
//                       decoration: const InputDecoration(
//                         fillColor: Colors.white,
//                         border: OutlineInputBorder(),
//                         hintText: "Post",
//                       ),
//                       validator: (value) {
//                         if (value!.isEmpty) {
//                           return 'Please enter your Post';
//                         }
//                         return null;
//                       },
//                     ),
//                   ),
//                   Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: TextFormField(
//                       controller: pinController,
//                       decoration: const InputDecoration(
//                         fillColor: Colors.white,
//                         border: OutlineInputBorder(),
//                         hintText: "Pin",
//                       ),
//                       validator: (value) {
//                         if (value!.isEmpty) {
//                           return 'Please enter your Pin';
//                         }
//                         return null;
//                       },
//                     ),
//                   ),
//                   Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: TextFormField(
//                       controller: usernameController,
//                       decoration: const InputDecoration(
//                         fillColor: Colors.white,
//                         border: OutlineInputBorder(),
//                         hintText: "Username",
//                       ),
//                       validator: (value) {
//                         if (value!.isEmpty) {
//                           return 'Please enter your Username';
//                         }
//                         return null;
//                       },
//                     ),
//                   ),
//                   Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: TextFormField(
//                       controller: passwordController,
//                       decoration: const InputDecoration(
//                         fillColor: Colors.white,
//                         border: OutlineInputBorder(),
//                         hintText: "Password",
//                       ),
//                       validator: (value) {
//                         if (value!.isEmpty) {
//                           return 'Please enter your Password';
//                         }
//                         return null;
//                       },
//                     ),
//                   ),
//                   Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: ElevatedButton.icon(
//                       onPressed: () async {
//                         if (_formKey.currentState!.validate()) {
//                           final sh = await SharedPreferences.getInstance();
//                           String name = nameController.text;
//                           String phone = phoneController.text;
//                           String place = placeController.text;
//                           String post = postController.text;
//                           String pin = pinController.text;
//                           String username = usernameController.text;
//                           String password = passwordController.text;
//
//                           String url = sh.getString("url").toString();
//                           var data = await http.post(
//                             Uri.parse("$url/registration"),
//                             body: {
//                               'name': name,
//                               'image': image,
//                               'phone': phone,
//                               'place': place,
//                               'post': post,
//                               'pin': pin,
//                               'uname': username,
//                               'password': password,
//                               'lid': sh.getString("lid").toString(),
//                             },
//                           );
//                           var jsonData = json.decode(data.body);
//                           if (jsonData['task'] == "valid") {
//                             Navigator.push(context,
//                                 MaterialPageRoute(builder: (context) => const login()));
//                           } else {
//                             print("Error in registration");
//                           }
//                         }
//                       },
//                       icon: const Icon(Icons.send),
//                       label: const Text('Submit'),
//                       style: ButtonStyle(
//                         backgroundColor: MaterialStateProperty.all<Color>(
//                           const Color(0xFF6ADC50),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ));
//   }
// }




import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

import 'login.dart';

class Registration extends StatefulWidget {
  const Registration({Key? key}) : super(key: key);

  @override
  _RegistrationState createState() => _RegistrationState();
}

class _RegistrationState extends State<Registration> {
  TextEditingController dateInputController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController placeController = TextEditingController();
  final TextEditingController postController = TextEditingController();
  final TextEditingController pinController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  String? selectedGender;
  final _formKey = GlobalKey<FormState>();

  XFile? _image;
  final ImagePicker _picker = ImagePicker();

  Future<void> _imgFromCamera() async {
    try {
      XFile? image = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 50,
      );
      if (image != null) {
        setState(() {
          _image = image;
        });
      } else {
        print('No image selected from camera.');
      }
    } catch (e) {
      print('Camera error: $e');
    }
  }

  Future<void> _imgFromGallery() async {
    try {
      XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 50,
      );
      if (image != null) {
        setState(() {
          _image = image;
        });
      } else {
        print('No image selected from gallery.');
      }
    } catch (e) {
      print('Gallery error: $e');
    }
  }

  void _showPicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text('Photo Library'),
                onTap: () {
                  _imgFromGallery();
                  Navigator.of(context).pop();
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_camera),
                title: const Text('Camera'),
                onTap: () {
                  _imgFromCamera();
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _submitRegistration() async {
    if (_formKey.currentState!.validate()) {
      final sh = await SharedPreferences.getInstance();
      String url = sh.getString("url") ?? '';
      if (url.isEmpty) {
        print("URL not found in shared preferences");
        return;
      }

      try {
        var request = http.MultipartRequest('POST', Uri.parse("$url/registration"));
        request.fields['name'] = nameController.text;
        request.fields['phone'] = phoneController.text;
        request.fields['place'] = placeController.text;
        request.fields['post'] = postController.text;
        request.fields['pin'] = pinController.text;
        request.fields['uname'] = usernameController.text;
        request.fields['password'] = passwordController.text;
        request.fields['lid'] = sh.getString("lid") ?? '';

        if (_image != null) {
          request.files.add(await http.MultipartFile.fromPath('image', _image!.path));
        }

        var response = await request.send();
        if (response.statusCode == 200) {
          var responseData = await http.Response.fromStream(response);
          var jsonData = json.decode(responseData.body);
          if (jsonData['task'] == "valid") {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => const login()));
          } else {
            print("Error: ${jsonData['message']}");
          }
        } else {
          print("Server error: ${response.statusCode}");
        }
      } catch (e) {
        print("Registration error: $e");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: const Text("SentriLock App"),
        ),
        body: SafeArea(
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  const Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        "Register",
                        style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () => _showPicker(context),
                    child: CircleAvatar(
                      radius: 55,
                      backgroundColor: const Color(0xffdbd8cd),
                      child: _image != null
                          ? ClipRRect(
                        borderRadius: BorderRadius.circular(50),
                        child: Image.file(
                          File(_image!.path),
                          width: 100,
                          height: 100,
                          fit: BoxFit.cover,
                        ),
                      )
                          : Container(
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(50),
                        ),
                        width: 100,
                        height: 100,
                        child: const Icon(
                          Icons.camera_alt,
                          color: Colors.grey,
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      controller: nameController,
                      decoration: const InputDecoration(
                        fillColor: Colors.white,
                        border: OutlineInputBorder(),
                        hintText: "Name",
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter your Full Name';
                        }
                        return null;
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      controller: phoneController,
                      decoration: const InputDecoration(
                        fillColor: Colors.white,
                        border: OutlineInputBorder(),
                        hintText: "Phone",
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      controller: placeController,
                      decoration: const InputDecoration(
                        fillColor: Colors.white,
                        border: OutlineInputBorder(),
                        hintText: "Place",
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter your Place';
                        }
                        return null;
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      controller: postController,
                      decoration: const InputDecoration(
                        fillColor: Colors.white,
                        border: OutlineInputBorder(),
                        hintText: "Post",
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter your Post';
                        }
                        return null;
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      controller: pinController,
                      decoration: const InputDecoration(
                        fillColor: Colors.white,
                        border: OutlineInputBorder(),
                        hintText: "Pin",
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter your Pin';
                        }
                        return null;
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      controller: usernameController,
                      decoration: const InputDecoration(
                        fillColor: Colors.white,
                        border: OutlineInputBorder(),
                        hintText: "Username",
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter your Username';
                        }
                        return null;
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      controller: passwordController,
                      decoration: const InputDecoration(
                        fillColor: Colors.white,
                        border: OutlineInputBorder(),
                        hintText: "Password",
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter your Password';
                        }
                        return null;
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: ElevatedButton.icon(
                      onPressed: _submitRegistration,
                      icon: const Icon(Icons.send),
                      label: const Text('Submit'),
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(
                          const Color(0xFF6ADC50),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ));
  }
}
