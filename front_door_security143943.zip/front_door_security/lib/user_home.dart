// import 'package:flutter/material.dart';
// import 'drawer.dart';
// class UserHome extends StatefulWidget {
//   const UserHome({super.key});
//
//   @override
//   State<UserHome> createState() => _UserHomeState();
// }
//
// class _UserHomeState extends State<UserHome> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         backgroundColor: Colors.white,
//         appBar: AppBar(
//           title: const Text("HOME"),
//         ),
//          drawer: const Drawerclass(),
//         body: SafeArea(
//             child:Container(decoration: BoxDecoration(
//                 image: DecorationImage(
//                   image: AssetImage("assets/backg.png"),
//                   fit: BoxFit.cover,)
//             ),))
//     );
//   }
// }
// //

import 'package:flutter/material.dart';
import 'package:front_door_security/complaint.dart';
import 'package:front_door_security/feedback.dart';
import 'package:front_door_security/newcomplaint.dart';
import 'package:front_door_security/notification.dart';
import 'package:front_door_security/userprofile.dart';
import 'package:front_door_security/viewauthority.dart';
import 'package:front_door_security/viewfamily_friends.dart';



void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<Map<String, dynamic>> premises = [
    // {'icon': Icons.home, 'label': 'Home', 'page': HomeScreen()},
    {'icon': Icons.person, 'label': 'Profile', 'page': ViewProfile()},
    {'icon': Icons.group, 'label': 'Family/Friends', 'page': FamilyFriendsPage()},
    {'icon': Icons.security, 'label': 'View Authority', 'page': viewROUTEUSER()},
    {'icon': Icons.feedback, 'label': 'Feedback', 'page': NewfeedbackPage()},
    {'icon': Icons.notifications, 'label': 'Notification', 'page': viewnotification(title: '',)},
    {'icon': Icons.report, 'label': 'Complaint', 'page': newcomplaint()},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade700,
      appBar: AppBar(
        backgroundColor: Colors.grey.shade700,
        title: Text('Welcome', style: TextStyle(color: Colors.white)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Select an option', style: TextStyle(color: Colors.white70)),
            SizedBox(height: 16),
            Expanded(
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.5,
                ),
                itemCount: premises.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => premises[index]['page'],
                        ),
                      );
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.black87,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(premises[index]['icon'], color: Colors.white, size: 30),
                          SizedBox(height: 8),
                          Text(
                            premises[index]['label'],
                            style: TextStyle(color: Colors.white, fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Individual screens for each section

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Home")),
      body: Center(child: Text("Welcome to Home Screen")),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Profile")),
      body: Center(child: Text("Profile Page")),
    );
  }
}

class FamilyFriendsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Family/Friends")),
      body: Center(child: Text("Family & Friends Page")),
    );
  }
}

class ViewAuthorityScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("View Authority")),
      body: Center(child: Text("View Authority Page")),
    );
  }
}

class FeedbackScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Feedback")),
      body: Center(child: Text("Feedback Page")),
    );
  }
}

class NotificationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Notification")),
      body: Center(child: Text("Notification Page")),
    );
  }
}

class ComplaintScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Complaint")),
      body: Center(child: Text("Complaint Page")),
    );
  }
}

// import 'package:flutter/material.dart';
// import 'drawer.dart';
// class UserHome extends StatefulWidget {
//   const UserHome({super.key});
//
//   @override
//   State<UserHome> createState() => _UserHomeState();
// }
//
// class _UserHomeState extends State<UserHome> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         backgroundColor: Colors.white,
//         appBar: AppBar(
//           title: const Text("HOME"),
//         ),
//         drawer: const Drawerclass(),
//         body: SafeArea(
//             child:Container(decoration: BoxDecoration(
//                 image: DecorationImage(
//                   image: AssetImage("assets/backg.png"),
//                   fit: BoxFit.cover,)
//             ),))
//     );
//   }
// }
