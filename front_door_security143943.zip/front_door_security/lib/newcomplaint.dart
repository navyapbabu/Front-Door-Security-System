// // import 'dart:convert';
// // import 'package:flutter/material.dart';
// // import 'package:http/http.dart' as http;
// // import 'package:shared_preferences/shared_preferences.dart';
// // class newcomplaint extends StatefulWidget {
// //   const newcomplaint({Key? key}) : super(key: key);
// //
// //   @override
// //   State<newcomplaint> createState() => _newcomplaintState();
// // }
// //
// // class _newcomplaintState extends State<newcomplaint> {
// //   List<dynamic> familyFriends = [];
// //   bool isLoading = true;
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     _fetchFamilyFriends();
// //   }
// //
// //   Future<void> _fetchFamilyFriends() async {
// //     final pref=await SharedPreferences.getInstance();
// //     String lid= pref.getString("lid").toString();
// //     String ip= pref.getString("url").toString();
// //     // String lid= pref.getString("lid").toString();
// //
// //     String apiUrl=ip+"viewfamiliarperson";
// //
// //
// //
// //     try {
// //       final response = await http.get(Uri.parse(apiUrl));
// //       if (response.statusCode == 200) {
// //         setState(() {
// //           familyFriends = jsonDecode(response.body);
// //           isLoading = false;
// //         });
// //       } else {
// //         setState(() {
// //           isLoading = false;
// //         });
// //         print('Error fetching data: ${response.statusCode}');
// //       }
// //     } catch (e) {
// //       setState(() {
// //         isLoading = false;
// //       });
// //       print('Error: $e');
// //     }
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text("Family Friends"),
// //       ),
// //       body: isLoading
// //           ? const Center(child: CircularProgressIndicator())
// //           : familyFriends.isEmpty
// //           ? const Center(child: Text("No data available"))
// //           : ListView.builder(
// //         itemCount: familyFriends.length,
// //         itemBuilder: (context, index) {
// //           final friend = familyFriends[index];
// //           return Card(
// //             margin: const EdgeInsets.all(8.0),
// //             child: ListTile(
// //               leading: CircleAvatar(
// //                 backgroundImage: NetworkImage(friend['image']),
// //               ),
// //               title: Text(friend['relationship']),
// //               subtitle: Text('User ID: ${friend['USER']}'),
// //             ),
// //           );
// //         },
// //       ),
// //     );
// //   }
// // }
//
//
//
//
//
// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class newcomplaint extends StatefulWidget {
//   const newcomplaint({Key? key}) : super(key: key);
//
//   @override
//   State<newcomplaint> createState() => _newcomplaintState();
// }
//
// class _newcomplaintState extends State<newcomplaint> {
//   List<dynamic> familyFriends = [];
//   bool isLoading = true;
//
//   @override
//   void initState() {
//     super.initState();
//     _fetchFamilyFriends();
//   }
//
//   Future<void> _fetchFamilyFriends() async {
//     final pref = await SharedPreferences.getInstance();
//     String? lid = pref.getString("lid");
//     String? ip = pref.getString("url");
//
//     if (lid == null || ip == null || lid.isEmpty || ip.isEmpty) {
//       print("Invalid SharedPreferences values.");
//       setState(() {
//         isLoading = false;
//       });
//       return;
//     }
//
//     String apiUrl = "$ip/viewfamiliarperson";
//
//     try {
//       final response =await http.post(Uri.parse(apiUrl), body: {
//         'lid':lid
//       });
//
//       if (response.statusCode == 200) {
//         final responseData = jsonDecode(response.body);
//         if (responseData['status'] == 'ok') {
//           setState(() {
//             familyFriends = responseData['data'];
//             isLoading = false;
//           });
//         } else {
//           setState(() {
//             isLoading = false;
//           });
//           print('Error in response: ${responseData}');
//         }
//       } else {
//         setState(() {
//           isLoading = false;
//         });
//         print('Error fetching data: ${response.statusCode}');
//       }
//     } catch (e) {
//       setState(() {
//         isLoading = false;
//       });
//       print('Error: $e');
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Family Friends"),
//       ),
//       body: isLoading
//           ? const Center(child: CircularProgressIndicator())
//           : familyFriends.isEmpty
//           ? const Center(child: Text("No data available"))
//           : ListView.builder(
//         itemCount: familyFriends.length,
//         itemBuilder: (context, index) {
//           final friend = familyFriends[index];
//           return Card(
//             margin: const EdgeInsets.all(8.0),
//             child: ListTile(
//               leading: CircleAvatar(
//                 backgroundImage: friend['image'] != null
//                     ? NetworkImage(friend['image'])
//                     : const AssetImage('assets/placeholder.png')
//                 as ImageProvider,
//               ),
//               title: Text(friend['relationship']),
//               // subtitle: Text('User ID: ${friend['USER']}'),
//             ),
//           );
//         },
//       ),
//
//     );
//   }
// }
// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:front_door_security/user_home.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
// import 'complaint.dart';
//
// class newcomplaint extends StatefulWidget {
//   const newcomplaint({Key? key}) : super(key: key);
//
//   @override
//   State<newcomplaint> createState() => _newcomplaintState();
// }
//
// class _newcomplaintState extends State<newcomplaint> {
//   List<dynamic> sendcomplaint = [];
//   bool isLoading = true;
//
//   @override
//   void initState() {
//     super.initState();
//     _fetchsendcomplaint();
//   }
//
//   Future<void> _fetchsendcomplaint() async {
//     final pref = await SharedPreferences.getInstance();
//     String? lid = pref.getString("lid");
//     String? ip = pref.getString("url");
//
//     if (lid == null || ip == null || lid.isEmpty || ip.isEmpty) {
//       print("Invalid SharedPreferences values.");
//       setState(() {
//         isLoading = false;
//       });
//       return;
//     }
//
//     String apiUrl = "$ip/viewcomplaints";
//
//     try {
//       final response = await http.post(Uri.parse(apiUrl), body: {'lid': lid});
//
//       if (response.statusCode == 200) {
//         final responseData = jsonDecode(response.body);
//         if (responseData['status'] == 'ok') {
//           setState(() {
//             sendcomplaint = responseData['data'];
//             isLoading = false;
//           });
//         } else {
//           setState(() {
//             isLoading = false;
//           });
//           print('Error in response: ${responseData}');
//         }
//       } else {
//         setState(() {
//           isLoading = false;
//         });
//         print('Error fetching data: ${response.statusCode}');
//       }
//     } catch (e) {
//       setState(() {
//         isLoading = false;
//       });
//       print('Error: $e');
//     }
//   }
//
//   // Future<void> _deleteFriend(int index) async {
//   //   final pref = await SharedPreferences.getInstance();
//   //   String? ip = pref.getString("url");
//   //
//   //   if (ip == null || ip.isEmpty) {
//   //     print("Invalid URL in SharedPreferences.");
//   //     return;
//   //   }
//   //
//   //   String apiUrl = "$ip/deletefamiliarperson";
//   //
//   //   try {
//   //     final response = await http.post(Uri.parse(apiUrl),
//   //         body: {'id': familyFriends[index]['id'].toString()});
//   //
//   //     if (response.statusCode == 200) {
//   //       final responseData = jsonDecode(response.body);
//   //       if (responseData['status'] == 'ok') {
//   //         setState(() {
//   //           familyFriends.removeAt(index);
//   //         });
//   //         print(" deleted successfully");
//   //       } else {
//   //         print("Failed to delete friend: ${responseData['error']}");
//   //       }
//   //     } else {
//   //       print('Error deleting data: ${response.statusCode}');
//   //     }
//   //   } catch (e) {
//   //     print('Error: $e');
//   //   }
//   // }
//
//   void _addNewFriend() {
//     // Implement your add friend logic or navigate to an add friend form page.
//     print("Navigate to Add Friend Page");
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Complaints"),
//       ),
//       body: isLoading
//           ? const Center(child: CircularProgressIndicator())
//           : sendcomplaint.isEmpty
//           ? const Center(child: Text("No data available"))
//           : ListView.builder(
//         itemCount: sendcomplaint.length,
//         itemBuilder: (context, index) {
//           final friend = sendcomplaint[index];
//           return Card(
//             margin: const EdgeInsets.all(8.0),
//             child: ListTile(
//               leading: CircleAvatar(
//                 backgroundImage: friend['image'] != null
//                     ? NetworkImage(friend['image'])
//                     : const AssetImage('assets/placeholder.png') as ImageProvider,
//               ),
//               title: Text(friend['subject']), // Title for the ListTile
//               subtitle: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(friend['content']), // Secondary content
//                   Text(friend['date'], style: TextStyle(color: Colors.grey)), // Date with a different style
//                   Text(friend['replay']), // Secondary content
//                 ],
//               ),
//               trailing: IconButton(
//                 icon: const Icon(Icons.delete, color: Colors.red),
//                 onPressed: () async {
//                   final sh = await SharedPreferences.getInstance();
//
//                   String? url = sh.getString("url");
//                   String? lid = sh.getString("lid");
//
//                   if (url != null && lid != null) {
//                     print("Deleting item...");
//                     try {
//                       var response = await http.post(
//                         Uri.parse(url+"deletecomplaint"),
//                         body: {
//                           'id': friend['id'].toString(),
//                         },
//                       );
//                       var jsonData = json.decode(response.body);
//                       if (jsonData['task'].toString() == "ok") {
//                         Navigator.pushReplacement(
//                           context,
//                           MaterialPageRoute(builder: (context) => newcomplaint()),
//                         );
//                       } else {
//                         print("Deletion failed");
//                       }
//                     } catch (error) {
//                       print("Error during deletion: $error");
//                     }
//                   } else {
//                     print("URL or ID not found in SharedPreferences");
//                   }
//                 },
//               ),
//             ),
//
//           );
//         },
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: () async {
//
//
//
//
//           Navigator.push(
//             context,
//
//             MaterialPageRoute(builder: (context) => complaint()),
//           );
//
//         },
//
//
//         child: const Icon(Icons.add),
//       ),
//     );
//   }
// }
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:front_door_security/user_home.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'complaint.dart';

class newcomplaint extends StatefulWidget {
  const newcomplaint({Key? key}) : super(key: key);

  @override
  State<newcomplaint> createState() => _newcomplaintState();
}

class _newcomplaintState extends State<newcomplaint> {
  List<dynamic> sendcomplaint = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchsendcomplaint();
  }

  Future<void> _fetchsendcomplaint() async {
    final pref = await SharedPreferences.getInstance();
    String? lid = pref.getString("lid");
    String? ip = pref.getString("url");

    if (lid == null || ip == null || lid.isEmpty || ip.isEmpty) {
      print("Invalid SharedPreferences values.");
      setState(() {
        isLoading = false;
      });
      return;
    }

    String apiUrl = "$ip/viewcomplaints";

    try {
      final response = await http.post(Uri.parse(apiUrl), body: {'lid': lid});

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        if (responseData['status'] == 'ok') {
          setState(() {
            sendcomplaint = responseData['data'];
            isLoading = false;
          });
        } else {
          setState(() {
            isLoading = false;
          });
          print('Error in response: \${responseData}');
        }
      } else {
        setState(() {
          isLoading = false;
        });
        print('Error fetching data: \${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print('Error: \$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Complaints"),
        backgroundColor: Colors.black,
      ),
      backgroundColor: Color(0xFF616161),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : sendcomplaint.isEmpty
          ? const Center(
        child: Text("No data available", style: TextStyle(color: Colors.white, fontSize: 18)),
      )
          : ListView.builder(
        itemCount: sendcomplaint.length,
        itemBuilder: (context, index) {
          final complaint = sendcomplaint[index];
          return Card(
            color: Colors.grey[850],
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ListTile(
              contentPadding: const EdgeInsets.all(12),
              leading: CircleAvatar(
                backgroundImage: complaint['image'] != null
                    ? NetworkImage(complaint['image'])
                    : const AssetImage('assets/placeholder.png') as ImageProvider,
              ),
              title: Text(
                complaint['subject'],
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 5),
                  Text(
                    complaint['content'],
                    style: TextStyle(color: Colors.grey[400]),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    complaint['date'],
                    style: const TextStyle(color: Colors.grey, fontSize: 12),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    complaint['replay'],
                    style: TextStyle(color: Colors.grey[300], fontStyle: FontStyle.italic),
                  ),
                ],
              ),
              trailing: IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: () async {
                  final sh = await SharedPreferences.getInstance();
                  String? url = sh.getString("url");
                  String? lid = sh.getString("lid");

                  if (url != null && lid != null) {
                    print("Deleting item...");
                    try {
                      var response = await http.post(
                        Uri.parse(url + "deletecomplaint"),
                        body: {'id': complaint['id'].toString()},
                      );
                      var jsonData = json.decode(response.body);
                      if (jsonData['task'].toString() == "ok") {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => newcomplaint()),
                        );
                      } else {
                        print("Deletion failed");
                      }
                    } catch (error) {
                      print("Error during deletion: \$error");
                    }
                  } else {
                    print("URL or ID not found in SharedPreferences");
                  }
                },
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => complaint()),
          );
        },
        backgroundColor: Colors.black,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}
