// import 'dart:convert';
// import 'dart:math';
//
//
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:http/http.dart' as http;
// import 'package:flutter/material.dart';
//
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:front_door_security/chat.dart';
//
//
//
//
//
//
//
// class viewROUTEUSER extends StatelessWidget {
//   const viewROUTEUSER({super.key});
//
//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Flutter Demo',
//       theme: ThemeData(
//         // This is the theme of your application.
//         //
//         // Try running your application with "flutter run". You'll see the
//         // application has a blue toolbar. Then, without quitting the app, try
//         // changing the primarySwatch below to Colors.green and then invoke
//         // "hot reload" (press "r" in the console where you ran "flutter run",
//         // or simply save your changes to "hot reload" in a Flutter IDE).
//         // Notice that the counter didn't reset back to zero; the application
//         // is not restarted.
//         primarySwatch: Colors.red,
//       ),
//       home: const viewauthoritypage(title: 'Flutter Demo Home Page'),
//       routes: {
//
//       },
//     );
//   }
// }
//
// class viewauthoritypage extends StatefulWidget {
//   const viewauthoritypage({super.key, required this.title});
//
//   // This widget is the home page of your application. It is stateful, meaning
//   // that it has a State object (defined below) that contains fields that affect
//   // how it looks.
//
//   // This class is the configuration for the state. It holds the values (in this
//   // case the title) provided by the parent (in this case the App widget) and
//   // used by the build method of the State. Fields in a Widget subclass are
//   // always marked "final".
//
//   final String title;
//
//   @override
//   State<viewauthoritypage> createState() => _viewauthoritypageState();
// }
//
// class _viewauthoritypageState extends State<viewauthoritypage> {
//   int _counter = 0;
//
//   _viewauthoritypageState() {
//     load();
//   }
//
//
//
//   List<String> ccid_ = <String>[];
//   List<String> name_ = <String>[];
//   List<String> place_ = <String>[];
//   List<String> phone_ = <String>[];
//   List<String> post_ = <String>[];
//   List<String> pin_= <String>[];
//   // List<String> age_ = <String>[];
//   // List<String> gender_ = <String>[];
//
//
//   Future<void> load() async {
//     List<String> ccid = <String>[];
//     List<String> name = <String>[];
//     List<String> place = <String>[];
//     List<String> phone = <String>[];
//     List<String> post = <String>[];
//     List<String> pin = <String>[];
//     // List<String> age = <String>[];
//     // List<String> gender = <String>[];
//
//
//
//     try {
//       final pref=await SharedPreferences.getInstance();
//       String lid= pref.getString("lid").toString();
//       String ip= pref.getString("url").toString();
//       // String lid= pref.getString("lid").toString();
//
//       String url=ip+"viewAuthority";
//       print(url);
//       var data = await http.post(Uri.parse(url), body: {
//         'lid':lid
//       });
//
//       var jsondata = json.decode(data.body);
//       String status = jsondata['status'];
//
//       var arr = jsondata["data"];
//       print("++++++++++=======================++++++++++");
//
//       print(arr);
//
//       print(arr.length);
//
//       // List<String> schid_ = <String>[];
//       // List<String> Name_ = <String>[];
//       // List<String> type_ = <String>[];
//
//       for (int i = 0; i < arr.length; i++) {
//
//         ccid.add(arr[i]['id'].toString());
//         name.add(arr[i]['name'].toString());
//         place.add(arr[i]['place'].toString());
//         phone.add(arr[i]['phonenumber'].toString());
//         // Phone.add(arr[i]['phone'].toString());
//         post.add(arr[i]['post'].toString());
//         pin.add(arr[i]['pin'].toString());
//         // gender.add(arr[i]['gender'].toString());
//       }
//       setState(() {
//         ccid_ = ccid;
//         name_ = name;
//         place_ = place;
//         phone_ = phone;
//         post_ = post;
//         pin_ = pin;
//         // age_ = age;
//         // gender_ = gender;
//       });
//       print(status);
//     } catch (e) {
//       print("Error ------------------- " + e.toString());
//       //there is error during converting file image to base64 encoding.
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     // This method is rerun every time setState is called, for instance as done
//     // by the _incrementCounter method above.
//     //
//     // The Flutter framework has been optimized to make rerunning build methods
//     // fast, so that you can just rebuild anything that needs updating rather
//     // than having to individually change instances of widgets.
//     return Scaffold(
//         appBar: AppBar(
//             title: new Text(
//               "VIEW AUTHORITY",
//               style: new TextStyle(color: Colors.white),
//             ),
//             leading: new IconButton(
//               icon: new Icon(Icons.arrow_back),
//               onPressed: () {
//                 Navigator.pop(context);
//                 // Navigator.pushNamed(context, '/home');
//                 // Navigator.push(context, MaterialPageRoute(builder: (context) => const  MyHomePage(title: '',)),);
//                 print("Hello");
//                 // Navigator.push(
//                 //   context,
//                 //   MaterialPageRoute(builder: (context) => ThirdScreen()),
//                 // );
//               },
//             )
//         ),
//
//         body:
//         ListView.builder(
//           physics: BouncingScrollPhysics(),
//           itemCount: ccid_.length,
//           itemBuilder: (BuildContext context, int index) {
//             return ListTile(
//               title: Padding(
//                 padding: const EdgeInsets.all(4.0),
//                 child: Column(
//                   children: [
//                     Container(
//                       width: MediaQuery.of(context).size.width,
//                       height: 350, // Adjusted height to accommodate the button
//                       child: Card(
//                         clipBehavior: Clip.antiAliasWithSaveLayer,
//                         child: Column(
//                           children: [
//                             SizedBox(height: 16),
//                             Row(
//                               children: [
//                                 SizedBox(width: 10),
//                                 Flexible(
//                                   flex: 2,
//                                   fit: FlexFit.loose,
//                                   child: Row(children: [Text("Name")]),
//                                 ),
//                                 Flexible(
//                                   flex: 3,
//                                   fit: FlexFit.loose,
//                                   child: Row(children: [Text(name_[index])]),
//                                 ),
//                               ],
//                             ),
//                             SizedBox(height: 16),
//                             Row(
//                               children: [
//                                 SizedBox(width: 10),
//                                 Flexible(
//                                   flex: 2,
//                                   fit: FlexFit.loose,
//                                   child: Row(children: [Text("Place")]),
//                                 ),
//                                 Flexible(
//                                   flex: 3,
//                                   fit: FlexFit.loose,
//                                   child: Row(children: [Text(place_[index])]),
//                                 ),
//                               ],
//                             ),
//                             SizedBox(height: 16),
//                             Row(
//                               children: [
//                                 SizedBox(width: 10),
//                                 Flexible(
//                                   flex: 2,
//                                   fit: FlexFit.loose,
//                                   child: Row(children: [Text("Phone")]),
//                                 ),
//                                 Flexible(
//                                   flex: 3,
//                                   fit: FlexFit.loose,
//                                   child: Row(children: [Text(phone_[index])]),
//                                 ),
//                               ],
//                             ),
//                             SizedBox(height: 16),
//                             Row(
//                               children: [
//                                 SizedBox(width: 10),
//                                 Flexible(
//                                   flex: 2,
//                                   fit: FlexFit.loose,
//                                   child: Row(children: [Text("Post")]),
//                                 ),
//                                 Flexible(
//                                   flex: 3,
//                                   fit: FlexFit.loose,
//                                   child: Row(children: [Text(post_[index])]),
//                                 ),
//                               ],
//                             ),
//                             SizedBox(height: 16),
//                             Row(
//                               children: [
//                                 SizedBox(width: 10),
//                                 Flexible(
//                                   flex: 2,
//                                   fit: FlexFit.loose,
//                                   child: Row(children: [Text("Pin")]),
//                                 ),
//                                 Flexible(
//                                   flex: 3,
//                                   fit: FlexFit.loose,
//                                   child: Row(children: [Text(pin_[index])]),
//                                 ),
//                               ],
//                             ),
//                             SizedBox(height: 16),
//                             ElevatedButton(
//                               onPressed: () async {
//                                 try {
//                                   String authorityId = ccid_[index]; // Get the authority ID
//                                   Fluttertoast.showToast(msg: "Chat with ID: $authorityId");
//
//                                   // Save authority ID in shared preferences (optional)
//                                   SharedPreferences sh = await SharedPreferences.getInstance();
//                                   sh.setString('clid', authorityId);
//
//                                   // Navigate to MyChatPage with the authority ID
//                                   Navigator.push(
//                                     context,
//                                     MaterialPageRoute(
//                                       builder: (context) => MyChatPage(title: 'Chat Page', clid: authorityId),
//                                     ),
//                                   );
//                                 } catch (e) {
//                                   Fluttertoast.showToast(msg: "Error: $e");
//                                 }
//                               },
//                               style: ElevatedButton.styleFrom(
//                                 backgroundColor: Colors.teal,  // Background color
//                               ),
//                               child: const Text(
//                                 "Chat",
//                                 style: TextStyle(color: Colors.white),
//                               ),
//                             ),
//
//                           ],
//                         ),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(10.0),
//                         ),
//                         elevation: 5,
//                         margin: EdgeInsets.all(10),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             );
//           },
//         )
//
//
//       // This trailing comma makes auto-formatting nicer for build methods.
//     );
//   }
//
//
//
//
// }


import 'dart:convert';
import 'dart:math';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:front_door_security/chat.dart';

class viewROUTEUSER extends StatelessWidget {
  const viewROUTEUSER({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: const viewauthoritypage(title: 'Flutter Demo Home Page'),
      routes: {},
    );
  }
}

class viewauthoritypage extends StatefulWidget {
  const viewauthoritypage({super.key, required this.title});
  final String title;

  @override
  State<viewauthoritypage> createState() => _viewauthoritypageState();
}

class _viewauthoritypageState extends State<viewauthoritypage> {
  int _counter = 0;
  _viewauthoritypageState() {
    load();
  }

  List<String> ccid_ = <String>[];
  List<String> name_ = <String>[];
  List<String> place_ = <String>[];
  List<String> phone_ = <String>[];
  List<String> post_ = <String>[];
  List<String> pin_ = <String>[];

  Future<void> load() async {
    List<String> ccid = <String>[];
    List<String> name = <String>[];
    List<String> place = <String>[];
    List<String> phone = <String>[];
    List<String> post = <String>[];
    List<String> pin = <String>[];

    try {
      final pref = await SharedPreferences.getInstance();
      String lid = pref.getString("lid").toString();
      String ip = pref.getString("url").toString();

      String url = ip + "viewAuthority";
      print(url);
      var data = await http.post(Uri.parse(url), body: {'lid': lid});
      var jsondata = json.decode(data.body);
      String status = jsondata['status'];
      var arr = jsondata["data"];
      print(arr);

      for (int i = 0; i < arr.length; i++) {
        ccid.add(arr[i]['id'].toString());
        name.add(arr[i]['name'].toString());
        place.add(arr[i]['place'].toString());
        phone.add(arr[i]['phonenumber'].toString());
        post.add(arr[i]['post'].toString());
        pin.add(arr[i]['pin'].toString());
      }
      setState(() {
        ccid_ = ccid;
        name_ = name;
        place_ = place;
        phone_ = phone;
        post_ = post;
        pin_ = pin;
      });
      print(status);
    } catch (e) {
      print("Error ------------------- " + e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "VIEW AUTHORITY",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      backgroundColor: Color(0xFF616161), // Background color changed
      body: ListView.builder(
        physics: const BouncingScrollPhysics(),
        itemCount: ccid_.length,
        itemBuilder: (BuildContext context, int index) {
          return ListTile(
            title: Padding(
              padding: const EdgeInsets.all(4.0),
              child: Card(
                clipBehavior: Clip.antiAliasWithSaveLayer,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                elevation: 5,
                margin: const EdgeInsets.all(10),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      infoRow("Name", name_[index]),
                      infoRow("Place", place_[index]),
                      infoRow("Phone", phone_[index]),
                      infoRow("Post", post_[index]),
                      infoRow("Pin", pin_[index]),
                      const SizedBox(height: 16),
                      Center(
                        child: ElevatedButton(
                          onPressed: () async {
                            try {
                              String authorityId = ccid_[index];
                              Fluttertoast.showToast(msg: "Chat with ID: $authorityId");
                              SharedPreferences sh = await SharedPreferences.getInstance();
                              sh.setString('clid', authorityId);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => MyChatPage(title: 'Chat Page', clid: authorityId),
                                ),
                              );
                            } catch (e) {
                              Fluttertoast.showToast(msg: "Error: $e");
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.teal,
                          ),
                          child: const Text(
                            "Chat",
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          SizedBox(width: 10),
          Flexible(
            flex: 2,
            fit: FlexFit.loose,
            child: Text("$label:", style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          Flexible(
            flex: 3,
            fit: FlexFit.loose,
            child: Text(value),
          ),
        ],
      ),
    );
  }
}
