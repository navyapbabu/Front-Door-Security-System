// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'dart:convert';
// import 'package:shared_preferences/shared_preferences.dart';
//
// class EditCriminalPage extends StatefulWidget {
//   final String id;
//   final String name;
//   final String crime;
//
//   const EditCriminalPage({Key? key, required this.id, required this.name, required this.crime}) : super(key: key);
//
//   @override
//   State<EditCriminalPage> createState() => _EditCriminalPageState();
// }
//
// class _EditCriminalPageState extends State<EditCriminalPage> {
//   late TextEditingController nameController;
//   late TextEditingController crimeController;
//
//   @override
//   void initState() {
//     super.initState();
//     nameController = TextEditingController(text: widget.name);
//     crimeController = TextEditingController(text: widget.crime);
//   }
//
//   Future<void> _updateCriminal() async {
//     final pref = await SharedPreferences.getInstance();
//     String? ip = pref.getString("url");
//
//     if (ip == null || ip.isEmpty) {
//       print("Invalid SharedPreferences values.");
//       return;
//     }
//
//     String apiUrl = "$ip/editcriminals";
//     try {
//       final response = await http.post(Uri.parse(apiUrl), body: {
//         'id': widget.id,
//         'name': nameController.text,
//         'crime': crimeController.text
//       });
//
//       final responseData = jsonDecode(response.body);
//       if (responseData['task'] == 'ok') {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('Criminal updated successfully')),
//         );
//         Navigator.pop(context, true); // Return success
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('Failed to update criminal')),
//         );
//       }
//     } catch (e) {
//       print('Error updating criminal: $e');
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text("Edit Criminal")),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           children: [
//             TextField(
//               controller: nameController,
//               decoration: const InputDecoration(labelText: "Name"),
//             ),
//             TextField(
//               controller: crimeController,
//               decoration: const InputDecoration(labelText: "Crime"),
//             ),
//             const SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: _updateCriminal,
//               child: const Text("Update"),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }import 'dart:convert';
// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class EditCriminalPage extends StatefulWidget {
//   final String id;
//   final String name;
//   final String crime;
//   final String imageUrl;
//
//   const EditCriminalPage({
//     Key? key,
//     required this.id,
//     required this.name,
//     required this.crime,
//     required this.imageUrl,
//   }) : super(key: key);
//
//   @override
//   State<EditCriminalPage> createState() => _EditCriminalPageState();
// }
//
// class _EditCriminalPageState extends State<EditCriminalPage> {
//   late TextEditingController nameController;
//   late TextEditingController crimeController;
//   File? _imageFile;
//   final ImagePicker _picker = ImagePicker();
//
//   @override
//   void initState() {
//     super.initState();
//     nameController = TextEditingController(text: widget.name);
//     crimeController = TextEditingController(text: widget.crime);
//   }
//
//   Future<void> _pickImage() async {
//     final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
//     if (pickedFile != null) {
//       setState(() {
//         _imageFile = File(pickedFile.path);
//       });
//     }
//   }
//
//   Future<void> _updateCriminal() async {
//     await _editCriminal(widget.id, nameController.text, crimeController.text, _imageFile);
//     Navigator.pop(context, true);
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text("Edit Criminal")),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           children: [
//             GestureDetector(
//               onTap: _pickImage,
//               child: CircleAvatar(
//                 radius: 50,
//                 backgroundImage: _imageFile != null
//                     ? FileImage(_imageFile!)
//                     : NetworkImage(widget.imageUrl) as ImageProvider,
//               ),
//             ),
//             const SizedBox(height: 10),
//             ElevatedButton(onPressed: _pickImage, child: const Text("Change Image")),
//             TextField(
//               controller: nameController,
//               decoration: const InputDecoration(labelText: "Name"),
//             ),
//             TextField(
//               controller: crimeController,
//               decoration: const InputDecoration(labelText: "Crime"),
//             ),
//             const SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: _updateCriminal,
//               child: const Text("Update"),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class EditCriminalPage extends StatefulWidget {
  final String id;
  final String name;
  final String crime;
  final String imageUrl;

  const EditCriminalPage({
    Key? key,
    required this.id,
    required this.name,
    required this.crime,
    required this.imageUrl,
  }) : super(key: key);

  @override
  State<EditCriminalPage> createState() => _EditCriminalPageState();
}

class _EditCriminalPageState extends State<EditCriminalPage> {
  late TextEditingController nameController;
  late TextEditingController crimeController;
  File? _imageFile;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.name);
    crimeController = TextEditingController(text: widget.crime);
  }

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  Future<void> _updateCriminal() async {
    final pref = await SharedPreferences.getInstance();
    String? ip = pref.getString("url");

    if (ip == null || ip.isEmpty) {
      print("Invalid SharedPreferences values.");
      return;
    }

    String apiUrl = "$ip/editcriminals";

    var request = http.MultipartRequest('POST', Uri.parse(apiUrl));
    request.fields['id'] = widget.id;
    request.fields['name'] = nameController.text;
    request.fields['crime'] = crimeController.text;

    if (_imageFile != null) {
      request.files.add(await http.MultipartFile.fromPath('image', _imageFile!.path));
    }

    try {
      var response = await request.send();
      var responseData = await response.stream.bytesToString();
      var jsonResponse = jsonDecode(responseData);

      if (jsonResponse['task'] == 'ok') {
        Navigator.pop(context, true);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Criminal updated successfully')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to update criminal')),
        );
      }
    } catch (e) {
      print('Error updating criminal: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Edit Criminal")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            GestureDetector(
              onTap: _pickImage,
              child: CircleAvatar(
                radius: 50,
                backgroundImage: _imageFile != null
                    ? FileImage(_imageFile!)
                    : NetworkImage(widget.imageUrl) as ImageProvider,
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton(onPressed: _pickImage, child: const Text("Change Image")),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: "Name"),
            ),
            TextField(
              controller: crimeController,
              decoration: const InputDecoration(labelText: "Crime"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _updateCriminal,
              child: const Text("Update"),
            ),
          ],
        ),
      ),
    );
  }
}
