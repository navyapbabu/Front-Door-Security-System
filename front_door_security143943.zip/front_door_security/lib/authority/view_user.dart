import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:front_door_security/authority/chat_with_user.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ViewUsersPage extends StatefulWidget {
  const ViewUsersPage({Key? key}) : super(key: key);

  @override
  State<ViewUsersPage> createState() => _ViewUsersPageState();
}

class _ViewUsersPageState extends State<ViewUsersPage> {
  List<dynamic> users = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    final pref = await SharedPreferences.getInstance();
    String? lid = pref.getString("lid");
    String? ip = pref.getString("url");

    if (lid == null || ip == null || lid.isEmpty || ip.isEmpty) {
      print("Invalid SharedPreferences values.");
      setState(() {
        isLoading = false;
      });
      return;
    }

    String apiUrl = "$ip/viewUser";

    try {
      final response = await http.post(Uri.parse(apiUrl), body: {'lid': lid});

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        if (responseData['status'] == 'ok') {
          setState(() {
            users = responseData['data'];
            isLoading = false;
          });
        } else {
          setState(() {
            isLoading = false;
          });
          print('Error in response: ${responseData}');
        }
      } else {
        setState(() {
          isLoading = false;
        });
        print('Error fetching data: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Users"),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : users.isEmpty
          ? const Center(child: Text("No data available"))
          : ListView.builder(
        itemCount: users.length,
        itemBuilder: (context, index) {
          final user = users[index];
          return Card(
            margin: const EdgeInsets.all(8.0),
            child: ListTile(
              leading: CircleAvatar(
                backgroundImage: user['image'] != null
                    ? NetworkImage(user['image'])
                    : const AssetImage('assets/placeholder.png')
                as ImageProvider,
              ),
              title: Text(user['name']),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Phone: ${user['phonenumber']}"),
                  Text("id: ${user['id']}"),
                  Text("Place: ${user['place']}, ${user['post']}, ${user['pin']}"),
                  SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () async {
                      try {
                        Fluttertoast.showToast(msg: "Chat with ID: ${user['id']}");
                        SharedPreferences sh = await SharedPreferences.getInstance();
                        sh.setString('clid', user['id'].toString()); // Ensure lid is a string
                        // Navigate to the ChatScreen and pass the tutor ID
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => athochat(title: '',),
                          ),
                        );
                      } catch (e) {
                        Fluttertoast.showToast(msg: "Error: $e");
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,  // Background color
                    ),
                    child: const Text(
                      "Chat",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}