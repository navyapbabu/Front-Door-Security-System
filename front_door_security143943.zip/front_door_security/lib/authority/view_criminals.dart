//
// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:front_door_security/authority/addcriminal.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class ViewCriminalsPage extends StatefulWidget {
//   const ViewCriminalsPage({Key? key}) : super(key: key);
//
//   @override
//   State<ViewCriminalsPage> createState() => _ViewCriminalsPageState();
// }
//
// class _ViewCriminalsPageState extends State<ViewCriminalsPage> {
//   List<dynamic> criminals = [];
//   bool isLoading = true;
//
//   @override
//   void initState() {
//     super.initState();
//     _fetchCriminals();
//   }
//
//   Future<void> _fetchCriminals() async {
//     final pref = await SharedPreferences.getInstance();
//     String? lid = pref.getString("lid");
//     String? ip = pref.getString("url");
//
//     if (lid == null || ip == null || lid.isEmpty || ip.isEmpty) {
//       print("Invalid SharedPreferences values.");
//       setState(() {
//         isLoading = false;
//       });
//       return;
//     }
//
//     String apiUrl = "$ip/autho_viewcriminals";
//
//     try {
//       final response = await http.post(Uri.parse(apiUrl), body: {'lid': lid});
//
//       if (response.statusCode == 200) {
//         final responseData = jsonDecode(response.body);
//         if (responseData['status'] == 'ok') {
//           setState(() {
//             criminals = responseData['data'];
//             isLoading = false;
//           });
//         } else {
//           setState(() {
//             isLoading = false;
//           });
//           print('Error in response: ${responseData}');
//         }
//       } else {
//         setState(() {
//           isLoading = false;
//         });
//         print('Error fetching data: ${response.statusCode}');
//       }
//     } catch (e) {
//       setState(() {
//         isLoading = false;
//       });
//       print('Error: $e');
//     }
//   }
//
//   Future<void> _deleteCriminal(String id) async {
//     final pref = await SharedPreferences.getInstance();
//     String? ip = pref.getString("url");
//
//     if (ip == null || ip.isEmpty) {
//       print("Invalid SharedPreferences values.");
//       return;
//     }
//
//     String apiUrl = "$ip/deletecriminals";
//
//     try {
//       final response = await http.post(Uri.parse(apiUrl), body: {'id': id});
//       final responseData = jsonDecode(response.body);
//
//       if (responseData['task'] == 'ok') {
//         setState(() {
//           criminals.removeWhere((criminal) => criminal['id'] == id);
//         });
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('Criminal deleted successfully')),
//         );
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('Failed to delete criminal')),
//         );
//       }
//     } catch (e) {
//       print('Error deleting criminal: $e');
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Criminals"),
//       ),
//       body: isLoading
//           ? const Center(child: CircularProgressIndicator())
//           : criminals.isEmpty
//           ? const Center(child: Text("No data available"))
//           : ListView.builder(
//         itemCount: criminals.length,
//         itemBuilder: (context, index) {
//           final criminal = criminals[index];
//           return Card(
//             margin: const EdgeInsets.all(8.0),
//             child: ListTile(
//               leading: CircleAvatar(
//                 backgroundImage: criminal['image'] != null
//                     ? NetworkImage(criminal['image'])
//                     : const AssetImage('assets/placeholder.png')
//                 as ImageProvider,
//               ),
//               title: Text(criminal['name']),
//               subtitle: Text("Crime: ${criminal['crime']}"),
//               trailing: IconButton(
//                 icon: Icon(Icons.delete, color: Colors.red),
//                 onPressed: () => _deleteCriminal(criminal['id'].toString()),
//               ),
//             ),
//           );
//         },
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: () {
//           Navigator.push(
//               context, MaterialPageRoute(builder: (context) => AddCriminalPerson()));
//         },
//         child: const Icon(Icons.add),
//       ),
//     );
//   }
// }
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:front_door_security/authority/addcriminal.dart';
import 'package:front_door_security/authority/edit_criminal.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ViewCriminalsPage extends StatefulWidget {
  const ViewCriminalsPage({Key? key}) : super(key: key);

  @override
  State<ViewCriminalsPage> createState() => _ViewCriminalsPageState();
}

class _ViewCriminalsPageState extends State<ViewCriminalsPage> {
  List<dynamic> criminals = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchCriminals();
  }

  Future<void> _fetchCriminals() async {
    final pref = await SharedPreferences.getInstance();
    String? lid = pref.getString("lid");
    String? ip = pref.getString("url");

    if (lid == null || ip == null || lid.isEmpty || ip.isEmpty) {
      print("Invalid SharedPreferences values.");
      setState(() {
        isLoading = false;
      });
      return;
    }

    String apiUrl = "$ip/autho_viewcriminals";

    try {
      final response = await http.post(Uri.parse(apiUrl), body: {'lid': lid});

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        if (responseData['status'] == 'ok') {
          setState(() {
            criminals = responseData['data'];
            isLoading = false;
          });
        } else {
          setState(() {
            isLoading = false;
          });
          print('Error in response: ${responseData}');
        }
      } else {
        setState(() {
          isLoading = false;
        });
        print('Error fetching data: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print('Error: $e');
    }
  }

  Future<void> _deleteCriminal(String id) async {
    final pref = await SharedPreferences.getInstance();
    String? ip = pref.getString("url");

    if (ip == null || ip.isEmpty) {
      print("Invalid SharedPreferences values.");
      return;
    }

    String apiUrl = "$ip/deletecriminals";

    try {
      final response = await http.post(Uri.parse(apiUrl), body: {'id': id});
      final responseData = jsonDecode(response.body);

      if (responseData['task'] == 'ok') {
        setState(() {
          criminals.removeWhere((criminal) => criminal['id'] == id);
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Criminal deleted successfully')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to delete criminal')),
        );
      }
    } catch (e) {
      print('Error deleting criminal: $e');
    }
  }

  Future<void> _editCriminal(String id, String name, String crime) async {
    final pref = await SharedPreferences.getInstance();
    String? ip = pref.getString("url");

    if (ip == null || ip.isEmpty) {
      print("Invalid SharedPreferences values.");
      return;
    }

    String apiUrl = "$ip/editcriminals";

    try {
      final response = await http.post(Uri.parse(apiUrl), body: {
        'id': id,
        'name': name,
        'crime': crime
      });
      final responseData = jsonDecode(response.body);

      if (responseData['task'] == 'ok') {
        _fetchCriminals();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Criminal updated successfully')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to update criminal')),
        );
      }
    } catch (e) {
      print('Error updating criminal: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Criminals"),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : criminals.isEmpty
          ? const Center(child: Text("No data available"))
          : ListView.builder(
        itemCount: criminals.length,
        itemBuilder: (context, index) {
          final criminal = criminals[index];
          return Card(
            margin: const EdgeInsets.all(8.0),
            child: ListTile(
              leading: CircleAvatar(
                backgroundImage: criminal['image'] != null
                    ? NetworkImage(criminal['image'])
                    : const AssetImage('assets/placeholder.png')
                as ImageProvider,
              ),
              title: Text(criminal['name']),
              subtitle: Text("Crime: ${criminal['crime']}"),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.edit, color: Colors.blue),
                      onPressed: () async {
                        bool? result = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => EditCriminalPage(
                              id: criminal['id'].toString(),
                              name: criminal['name'],
                              crime: criminal['crime'],
                              imageUrl: criminal['image'], // Pass the image URL
                            ),
                          ),
                        );

                        if (result == true) {
                          _fetchCriminals(); // Refresh the list if changes were made
                        }
                      },

                  ),


                  IconButton(
                    icon: Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _deleteCriminal(criminal['id'].toString()),
                  ),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => AddCriminalPerson()));
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
