import 'package:flutter/material.dart';

import 'ipset.dart';

void main() {
  runApp(const doorsecu());
}

class doorsecu extends StatefulWidget {
  const doorsecu({super.key});

  @override
  State<doorsecu> createState() => _doorsecuState();
}

class _doorsecuState extends State<doorsecu> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const ipset(),
    );
  }
}