//
// import 'package:flutter/material.dart';
//
// import 'login.dart';
// class Drawerclass extends StatelessWidget {
//   const Drawerclass({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Drawer(
//       child: ListView(
//         padding: EdgeInsets.zero,
//         children: <Widget>[
//           const DrawerHeader(
//             decoration: BoxDecoration(
//               color: Colors.red,
//             ),
//             child: Text(
//               "My App",
//               style: TextStyle(color: Colors.black, fontSize: 24),
//             ),
//           ),
//           ListTile(
//             leading: IconButton(
//               onPressed: () {
//                 // Handle icon button press
//               },
//               icon: const Icon(Icons.home),
//             ),
//             title: const Text("Home"),
//             onTap: () {
//               // Navigator.push(context, MaterialPageRoute(builder: (context) => const home()));
//             },
//
//           ),
//           ListTile(
//             leading:
//             IconButton(onPressed: () {}, icon: const Icon(Icons.directions_bus)),
//             title: const Text("MANAGE FAMILY/FRIENDS MEMBERS"),
//             onTap: () {
//               // Navigator.push(context, MaterialPageRoute(builder: (context) => viewbususer()));
//             },
//           ),
//           ListTile(
//             leading: IconButton(onPressed: () {}, icon: const Icon(Icons.bus_alert)),
//             title: const Text("WRITE A FEEDBACK"),
//             onTap: () {
//               // Navigator.push(context, MaterialPageRoute(builder: (context) => PaymentScreen()));
//
//             },
//           ),
//           ListTile(
//             leading: IconButton(onPressed: () {}, icon: const Icon(Icons.feedback)),
//             title: const Text("WRITE A COMPLAINT"),
//             onTap: () {
//               // Navigator.push(context, MaterialPageRoute(builder: (context) => feedback()));
//
//             },
//           ),
//           ListTile(
//             leading: IconButton(onPressed: () {}, icon: const Icon(Icons.book_online)),
//             title: const Text("NOTIFICATIONS"),
//             onTap: () {
//               // Navigator.push(context, MaterialPageRoute(builder: (context) => BookingPage()));
//
//             },
//           ),
//
//
//           ListTile(
//             leading: IconButton(onPressed: () {}, icon: const Icon(Icons.logout)),
//             title: const Text("Logout"),
//             onTap: () {
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(builder: (context) => const login()),
//               );
//             },
//           ),
//         ],
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:front_door_security/addfamily_friends.dart';
import 'package:front_door_security/complaint.dart';
import 'package:front_door_security/newcomplaint.dart';
import 'package:front_door_security/notification.dart';
import 'package:front_door_security/user_home.dart';
import 'package:front_door_security/userprofile.dart';
import 'package:front_door_security/viewauthority.dart';
import 'package:front_door_security/viewfamily_friends.dart';
import 'package:front_door_security/feedback.dart';



import 'login.dart';

class Drawerclass extends StatelessWidget {
  const Drawerclass({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          const DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
            child: Text(
              "My App",
              style: TextStyle(color: Colors.black, fontSize: 24),
            ),
          ),
          // ListTile(
          //   leading: const Icon(Icons.home), // Home icon for Home
          //   title: const Text("Home"),
          //   onTap: () {
          //     Navigator.push(context, MaterialPageRoute(builder: (context) =>  UserHome()));
          //   },
          // ),
          ListTile(
            leading: const Icon(Icons.person), // Home icon for Home
            title: const Text("PROFILE"),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => ViewProfile()));
            },
          ),
          ListTile(
            leading: const Icon(Icons.group), // Group icon for Manage Family/Friends
            title: const Text("MANAGE FAMILY/FRIENDS MEMBERS"),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => FamilyFriendsPage()));
            },
          ),ListTile(
            leading: const Icon(Icons.group), // Group icon for Manage Family/Friends
            title: const Text("VIEW AUTHORITY"),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => viewauthoritypage(title: '',)));
            },
          ),
          ListTile(
            leading: const Icon(Icons.rate_review), // Review icon for Feedback
            title: const Text("WRITE A FEEDBACK"),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => NewfeedbackPage()));
            },
          ),
          ListTile(
            leading: const Icon(Icons.report_problem), // Complaint icon for Write a Complaint
            title: const Text("WRITE A COMPLAINT"),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => newcomplaint()));
            },
          ),
          ListTile(
            leading: const Icon(Icons.notifications), // Notification icon for Notifications
            title: const Text("NOTIFICATIONS"),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => viewnotification(title: '',)));
            },
          ),
          ListTile(
            leading: const Icon(Icons.logout), // Logout icon for Logout
            title: const Text("Logout"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const login()),
              );
            },
          ),
        ],
      ),
    );
  }
}
