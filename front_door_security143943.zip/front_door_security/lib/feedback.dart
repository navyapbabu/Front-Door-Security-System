// import 'dart:convert';
//
//
// import 'package:flutter/material.dart';
//
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// import 'user_home.dart';
//
// class NewfeedbackPage extends StatefulWidget {
//   @override
//   _NewfeedbackPageState createState() => _NewfeedbackPageState();
// }
//
// class _NewfeedbackPageState extends State<NewfeedbackPage> {
//   final TextEditingController _feedbackController = TextEditingController();
//
//   @override
//   void dispose() {
//     _feedbackController.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Write a New feedback"),
//       ),
//       body: Padding(
//         padding: EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.center,
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             TextField(
//               controller: _feedbackController,
//               decoration: InputDecoration(
//                 hintText: "Enter your feedback...",
//               ),
//             ),
//             ElevatedButton(
//               onPressed: () async {
//                 final sh = await SharedPreferences.getInstance();
//                 String feedback = _feedbackController.text.toString();
//                 // String Passwd=passwordController.text.toString();
//                 String url = sh.getString("url").toString();
//                 String lid = sh.getString("lid").toString();
//                 print("okkkkkkkkkkkkkkkkk");
//                 var data = await http.post(
//                     Uri.parse(url + "sendfeedback"),
//                     body: {'feedback': feedback,
//                       'lid': lid,
//
//                     });
//                 var jasondata = json.decode(data.body);
//                 String status = jasondata['status'].toString();
//                 if (status == "ok") {
//                   Navigator.push(context,
//                       MaterialPageRoute(builder: (context) => HomePage()));
//                 }
//                 else {
//                   print("error");
//                 }
//               },
//               child: Text("Submit feedback"),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }



import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'user_home.dart';

class NewfeedbackPage extends StatefulWidget {
  @override
  _NewfeedbackPageState createState() => _NewfeedbackPageState();
}

class _NewfeedbackPageState extends State<NewfeedbackPage> {
  final TextEditingController _feedbackController = TextEditingController();

  @override
  void dispose() {
    _feedbackController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Write a New Feedback"),
        backgroundColor: Colors.black,
      ),
      backgroundColor: Color(0xFF616161),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _feedbackController,
              decoration: InputDecoration(
                hintText: "Enter your feedback...",
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                  borderSide: BorderSide.none,
                ),
              ),
              maxLines: 5,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                final sh = await SharedPreferences.getInstance();
                String feedback = _feedbackController.text.toString();
                String url = sh.getString("url").toString();
                String lid = sh.getString("lid").toString();
                print("okkkkkkkkkkkkkkkkk");
                var data = await http.post(
                    Uri.parse(url + "sendfeedback"),
                    body: {'feedback': feedback, 'lid': lid});
                var jasondata = json.decode(data.body);
                String status = jasondata['status'].toString();
                if (status == "ok") {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => HomePage()));
                } else {
                  print("error");
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
              child: Text(
                "Submit Feedback",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
