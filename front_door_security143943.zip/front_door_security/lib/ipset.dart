// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import 'login.dart';
//
// class ipset extends StatefulWidget {
//   const ipset({super.key});
//
//   @override
//   State<ipset> createState() => _ipsetstate();
// }
//
// class _ipsetstate extends State<ipset> {
//   final TextEditingController ipController = TextEditingController();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         title: const Text("FDS APP"),
//       ),
//       body: SafeArea(
//         child: Center(
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             crossAxisAlignment: CrossAxisAlignment.center,
//             children: [
//               Padding(
//                 padding: const EdgeInsets.all(2),
//                 child: TextField(
//
//                   controller: ipController,
//                   decoration: const InputDecoration(
//                       border: OutlineInputBorder(),
//                       labelText: "IP Address",
//                       hintText: "Enter a valid ip address"),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: ElevatedButton(
//                   onPressed: () async{
//                     String ip=ipController.text.toString();
//                     final sh = await SharedPreferences.getInstance();
//                     sh.setString("url", "http://"+ip+":5000/");
//                     Navigator.push(context, MaterialPageRoute(builder: (context) => login()));
//                   },
//                   child: const Icon(Icons.key),
//
//                   style: ButtonStyle(
//                     backgroundColor: MaterialStateProperty.all<Color>(
//                       Colors.blue, // Use a proper color value (e.g., Hex or RGB)
//                     ),
//                   ),
//                 ),
//               )
//
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }



import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'login.dart';

class ipset extends StatefulWidget {
  const ipset({super.key});

  @override
  State<ipset> createState() => _ipsetstate();
}

class _ipsetstate extends State<ipset> {
  final TextEditingController ipController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("FDS APP", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.grey[900],
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.all(10),
                child: TextField(
                  controller: ipController,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderSide: BorderSide(color: Colors.white)),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blue),
                    ),
                    labelText: "IP Address",
                    labelStyle: TextStyle(color: Colors.white70),
                    hintText: "Enter a valid IP address",
                    hintStyle: TextStyle(color: Colors.white38),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: ElevatedButton(
                  onPressed: () async {
                    String ip = ipController.text.toString();
                    final sh = await SharedPreferences.getInstance();
                    sh.setString("url", "http://" + ip + ":5000/");
                    Navigator.push(context, MaterialPageRoute(builder: (context) => login()));
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Icon(Icons.key, color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
