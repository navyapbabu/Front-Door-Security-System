// // import 'dart:convert';
// // import 'package:flutter/material.dart';
// // import 'package:http/http.dart' as http;
// // import 'package:shared_preferences/shared_preferences.dart';
// // class FamilyFriendsPage extends StatefulWidget {
// //   const FamilyFriendsPage({Key? key}) : super(key: key);
// //
// //   @override
// //   State<FamilyFriendsPage> createState() => _FamilyFriendsPageState();
// // }
// //
// // class _FamilyFriendsPageState extends State<FamilyFriendsPage> {
// //   List<dynamic> familyFriends = [];
// //   bool isLoading = true;
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     _fetchFamilyFriends();
// //   }
// //
// //   Future<void> _fetchFamilyFriends() async {
// //     final pref=await SharedPreferences.getInstance();
// //     String lid= pref.getString("lid").toString();
// //     String ip= pref.getString("url").toString();
// //     // String lid= pref.getString("lid").toString();
// //
// //     String apiUrl = '$ip/viewfamiliarperson?lid=$lid';  // Append the 'lid' to the URL
// //
// //
// //
// //     try {
// //       final response = await http.get(Uri.parse(apiUrl));
// //       if (response.statusCode == 200) {
// //         print(jsonDecode(response.body)['data']);
// //         print(jsonDecode(response.body));
// //         setState(() {
// //           familyFriends = jsonDecode(response.body)['data'];
// //
// //           isLoading = false;
// //         });
// //       } else {
// //         setState(() {
// //           isLoading = false;
// //         });
// //         print('Error fetching data: ${response.statusCode}');
// //       }
// //     } catch (e) {
// //       setState(() {
// //         isLoading = false;
// //       });
// //       print('Error: $e');
// //     }
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text("Family Friends"),
// //       ),
// //       body: isLoading
// //           ? const Center(child: CircularProgressIndicator())
// //           : familyFriends.isEmpty
// //           ? const Center(child: Text("No data available"))
// //           : ListView.builder(
// //         itemCount: familyFriends.length,
// //         itemBuilder: (context, index) {
// //           final friend = familyFriends[index];
// //           return Card(
// //             margin: const EdgeInsets.all(8.0),
// //             child: ListTile(
// //               leading: CircleAvatar(
// //                 backgroundImage: NetworkImage(friend['image']),
// //               ),
// //               title: Text(friend['relationship']),
// //               subtitle: Text('User ID: ${friend['USER']}'),
// //             ),
// //           );
// //         },
// //       ),
// //     );
// //   }
// // }
// //
// //
// //
// // //
// //
// //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
// // // import 'dart:convert';
// // // import 'package:flutter/material.dart';
// // // import 'package:http/http.dart' as http;
// // // import 'package:shared_preferences/shared_preferences.dart';
// // // class FamilyFriendsPage extends StatefulWidget {
// // //   const FamilyFriendsPage({Key? key}) : super(key: key);
// // //
// // //   @override
// // //   State<FamilyFriendsPage> createState() => _FamilyFriendsPageState();
// // // }
// // //
// // // class _FamilyFriendsPageState extends State<FamilyFriendsPage> {
// // //   List<dynamic> familyFriends = [];
// // //   bool isLoading = true;
// // //
// // //   @override
// // //   void initState() {
// // //     super.initState();
// // //     _fetchFamilyFriends();
// // //   }
// // //
// // //   Future<void> _fetchFamilyFriends() async {
// // //     final pref=await SharedPreferences.getInstance();
// // //     String lid= pref.getString("lid").toString();
// // //     String ip= pref.getString("url").toString();
// // //     // String lid= pref.getString("lid").toString();
// // //
// // //     String apiUrl=ip+"viewfamiliarperson";
// // //
// // //
// // //
// // //     try {
// // //       final response = await http.get(Uri.parse(apiUrl));
// // //       if (response.statusCode == 200) {
// // //         setState(() {
// // //           familyFriends = jsonDecode(response.body);
// // //           isLoading = false;
// // //         });
// // //       } else {
// // //         setState(() {
// // //           isLoading = false;
// // //         });
// // //         print('Error fetching data: ${response.statusCode}');
// // //       }
// // //     } catch (e) {
// // //       setState(() {
// // //         isLoading = false;
// // //       });
// // //       print('Error: $e');
// // //     }
// // //   }
// // //
// // //   @override
// // //   Widget build(BuildContext context) {
// // //     return Scaffold(
// // //       appBar: AppBar(
// // //         title: const Text("Family Friends"),
// // //       ),
// // //       body: isLoading
// // //           ? const Center(child: CircularProgressIndicator())
// // //           : familyFriends.isEmpty
// // //           ? const Center(child: Text("No data available"))
// // //           : ListView.builder(
// // //         itemCount: familyFriends.length,
// // //         itemBuilder: (context, index) {
// // //           final friend = familyFriends[index];
// // //           return Card(
// // //             margin: const EdgeInsets.all(8.0),
// // //             child: ListTile(
// // //               leading: CircleAvatar(
// // //                 backgroundImage: NetworkImage(friend['image']),
// // //               ),
// // //               title: Text(friend['relationship']),
// // //               subtitle: Text('User ID: ${friend['USER']}'),
// // //             ),
// // //           );
// // //         },
// // //       ),
// // //     );
// // //   }
// // // }
// //
// //
// //
// //
// //
// // import 'dart:convert';
// // import 'package:flutter/material.dart';
// // import 'package:http/http.dart' as http;
// // import 'package:shared_preferences/shared_preferences.dart';
// //
// // class FamilyFriendsPage extends StatefulWidget {
// //   const FamilyFriendsPage({Key? key}) : super(key: key);
// //
// //   @override
// //   State<FamilyFriendsPage> createState() => _FamilyFriendsPageState();
// // }
// //
// // class _FamilyFriendsPageState extends State<FamilyFriendsPage> {
// //   List<dynamic> familyFriends = [];
// //   bool isLoading = true;
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     _fetchFamilyFriends();
// //   }
// //
// //   Future<void> _fetchFamilyFriends() async {
// //     final pref = await SharedPreferences.getInstance();
// //     String? lid = pref.getString("lid");
// //     String? ip = pref.getString("url");
// //
// //     if (lid == null || ip == null || lid.isEmpty || ip.isEmpty) {
// //       print("Invalid SharedPreferences values.");
// //       setState(() {
// //         isLoading = false;
// //       });
// //       return;
// //     }
// //
// //     String apiUrl = "$ip/viewfamiliarperson";
// //
// //     try {
// //       final response =await http.post(Uri.parse(apiUrl), body: {
// //         'lid':lid
// //       });
// //
// //       if (response.statusCode == 200) {
// //         final responseData = jsonDecode(response.body);
// //         if (responseData['status'] == 'ok') {
// //           setState(() {
// //             familyFriends = responseData['data'];
// //             isLoading = false;
// //           });
// //         } else {
// //           setState(() {
// //             isLoading = false;
// //           });
// //           print('Error in response: ${responseData}');
// //         }
// //       } else {
// //         setState(() {
// //           isLoading = false;
// //         });
// //         print('Error fetching data: ${response.statusCode}');
// //       }
// //     } catch (e) {
// //       setState(() {
// //         isLoading = false;
// //       });
// //       print('Error: $e');
// //     }
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text("Family Friends"),
// //       ),
// //       body: isLoading
// //           ? const Center(child: CircularProgressIndicator())
// //           : familyFriends.isEmpty
// //           ? const Center(child: Text("No data available"))
// //           : ListView.builder(
// //         itemCount: familyFriends.length,
// //         itemBuilder: (context, index) {
// //           final friend = familyFriends[index];
// //           return Card(
// //             margin: const EdgeInsets.all(8.0),
// //             child: ListTile(
// //               leading: CircleAvatar(
// //                 backgroundImage: friend['image'] != null
// //                     ? NetworkImage(friend['image'])
// //                     : const AssetImage('assets/placeholder.png')
// //                 as ImageProvider,
// //               ),
// //               title: Text(friend['relationship']),
// //               // subtitle: Text('User ID: ${friend['USER']}'),
// //             ),
// //           );
// //         },
// //       ),
// //
// //     );
// //   }
// // }
//
//
//
// // import 'dart:convert';
// // import 'package:flutter/material.dart';
// // import 'package:front_door_security/user_home.dart';
// // import 'package:http/http.dart' as http;
// // import 'package:shared_preferences/shared_preferences.dart';
// // import 'addfamily_friends.dart';
// //
// // class FamilyFriendsPage extends StatefulWidget {
// //   const FamilyFriendsPage({Key? key}) : super(key: key);
// //
// //   @override
// //   State<FamilyFriendsPage> createState() => _FamilyFriendsPageState();
// // }
// //
// // class _FamilyFriendsPageState extends State<FamilyFriendsPage> {
// //   List<dynamic> familyFriends = [];
// //   bool isLoading = true;
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     _fetchFamilyFriends();
// //   }
// //
// //   Future<void> _fetchFamilyFriends() async {
// //     final pref = await SharedPreferences.getInstance();
// //     String? lid = pref.getString("lid");
// //     String? ip = pref.getString("url");
// //
// //     if (lid == null || ip == null || lid.isEmpty || ip.isEmpty) {
// //       print("Invalid SharedPreferences values.");
// //       setState(() {
// //         isLoading = false;
// //       });
// //       return;
// //     }
// //
// //     String apiUrl = "$ip/viewfamiliarperson";
// //
// //     try {
// //       final response = await http.post(Uri.parse(apiUrl), body: {'lid': lid});
// //
// //       if (response.statusCode == 200) {
// //         final responseData = jsonDecode(response.body);
// //         if (responseData['status'] == 'ok') {
// //           setState(() {
// //             familyFriends = responseData['data'];
// //             isLoading = false;
// //           });
// //         } else {
// //           setState(() {
// //             isLoading = false;
// //           });
// //           print('Error in response: ${responseData}');
// //         }
// //       } else {
// //         setState(() {
// //           isLoading = false;
// //         });
// //         print('Error fetching data: ${response.statusCode}');
// //       }
// //     } catch (e) {
// //       setState(() {
// //         isLoading = false;
// //       });
// //       print('Error: $e');
// //     }
// //   }
// //
// //   Future<void> _deleteFriend(int index) async {
// //     final pref = await SharedPreferences.getInstance();
// //     String? ip = pref.getString("url");
// //
// //     if (ip == null || ip.isEmpty) {
// //       print("Invalid URL in SharedPreferences.");
// //       return;
// //     }
// //
// //     String apiUrl = "$ip/deletefamiliarperson";
// //
// //     try {
// //       final response = await http.post(Uri.parse(apiUrl),
// //           body: {'id': familyFriends[index]['id'].toString()});
// //
// //       if (response.statusCode == 200) {
// //         final responseData = jsonDecode(response.body);
// //         if (responseData['status'] == 'ok') {
// //           setState(() {
// //             familyFriends.removeAt(index);
// //           });
// //           print(" deleted successfully");
// //         } else {
// //           print("Failed to delete friend: ${responseData['error']}");
// //         }
// //       } else {
// //         print('Error deleting data: ${response.statusCode}');
// //       }
// //     } catch (e) {
// //       print('Error: $e');
// //     }
// //   }
// //
// //   void _addNewFriend() {
// //     // Implement your add friend logic or navigate to an add friend form page.
// //     print("Navigate to Add Friend Page");
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text("Family Friends"),
// //       ),
// //       body: isLoading
// //           ? const Center(child: CircularProgressIndicator())
// //           : familyFriends.isEmpty
// //           ? const Center(child: Text("No data available"))
// //           : ListView.builder(
// //         itemCount: familyFriends.length,
// //         itemBuilder: (context, index) {
// //           final friend = familyFriends[index];
// //           return Card(
// //             margin: const EdgeInsets.all(8.0),
// //             child: ListTile(
// //               leading: CircleAvatar(
// //                 backgroundImage: friend['image'] != null
// //                     ? NetworkImage(friend['image'])
// //                     : const AssetImage('assets/placeholder.png')
// //                 as ImageProvider,
// //               ),
// //               title: Text(friend['relationship']),
// //               trailing: IconButton(
// //                 icon: const Icon(Icons.delete, color: Colors.red),
// //                 onPressed: () async {
// //                   final sh = await SharedPreferences.getInstance();
// //
// //                   String url = sh.getString("url").toString();
// //                   String lid = sh.getString("lid").toString();
// //                   print("okkkkkkkkkkkkkkkkk");
// //                   var data = await http.post(
// //                       Uri.parse(url + "deletefamiliarperson"),
// //                       body: {
// //
// //
// //                         'id': friend['id'].toString(),
// //
// //                       });
// //                   var jasondata = json.decode(data.body);
// //                   String status = jasondata['task'].toString();
// //                   if (status == "ok") {
// //                     Navigator.push(context,
// //                         MaterialPageRoute(builder: (context) => FamilyFriendsPage()));
// //                   }
// //                   else {
// //                     print("error");
// //                   }
// //                 },
// //               ),
// //             ),
// //           );
// //         },
// //       ),
// //       floatingActionButton: FloatingActionButton(
// //         onPressed: () async {
// //
// //
// //
// //
// //           Navigator.push(
// //             context,
// //
// //             MaterialPageRoute(builder: (context) => addfamiliarperson()),
// //           );
// //
// //         },
// //
// //
// //         child: const Icon(Icons.add),
// //       ),
// //     );
// //   }
// // }
//
//
//
//
//
// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:front_door_security/user_home.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
// import 'addfamily_friends.dart';
//
// class FamilyFriendsPage extends StatefulWidget {
//   const FamilyFriendsPage({Key? key}) : super(key: key);
//
//   @override
//   State<FamilyFriendsPage> createState() => _FamilyFriendsPageState();
// }
//
// class _FamilyFriendsPageState extends State<FamilyFriendsPage> {
//   List<dynamic> familyFriends = [];
//   bool isLoading = true;
//
//   @override
//   void initState() {
//     super.initState();
//     _fetchFamilyFriends();
//   }
//
//   Future<void> _fetchFamilyFriends() async {
//     final pref = await SharedPreferences.getInstance();
//     String? lid = pref.getString("lid");
//     String? ip = pref.getString("url");
//
//     if (lid == null || ip == null || lid.isEmpty || ip.isEmpty) {
//       print("Invalid SharedPreferences values.");
//       setState(() {
//         isLoading = false;
//       });
//       return;
//     }
//
//     String apiUrl = "$ip/viewfamiliarperson";
//
//     try {
//       final response = await http.post(Uri.parse(apiUrl), body: {'lid': lid});
//
//       if (response.statusCode == 200) {
//         final responseData = jsonDecode(response.body);
//         if (responseData['status'] == 'ok') {
//           setState(() {
//             familyFriends = responseData['data'];
//             isLoading = false;
//           });
//         } else {
//           setState(() {
//             isLoading = false;
//           });
//           print('Error in response: ${responseData}');
//         }
//       } else {
//         setState(() {
//           isLoading = false;
//         });
//         print('Error fetching data: ${response.statusCode}');
//       }
//     } catch (e) {
//       setState(() {
//         isLoading = false;
//       });
//       print('Error: $e');
//     }
//   }
//
//   Future<void> _deleteFriend(int index) async {
//     final pref = await SharedPreferences.getInstance();
//     String? ip = pref.getString("url");
//
//     if (ip == null || ip.isEmpty) {
//       print("Invalid URL in SharedPreferences.");
//       return;
//     }
//
//     String apiUrl = "$ip/deletefamiliarperson";
//
//     try {
//       final response = await http.post(Uri.parse(apiUrl),
//           body: {'id': familyFriends[index]['id'].toString()});
//
//       if (response.statusCode == 200) {
//         final responseData = jsonDecode(response.body);
//         if (responseData['status'] == 'ok') {
//           setState(() {
//             familyFriends.removeAt(index);
//           });
//           print(" deleted successfully");
//         } else {
//           print("Failed to delete friend: ${responseData['error']}");
//         }
//       } else {
//         print('Error deleting data: ${response.statusCode}');
//       }
//     } catch (e) {
//       print('Error: $e');
//     }
//   }
//
//   void _addNewFriend() {
//     // Implement your add friend logic or navigate to an add friend form page.
//     print("Navigate to Add Friend Page");
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text(
//           "Family & Friends",
//           style: TextStyle(
//             fontWeight: FontWeight.bold,
//             fontSize: 24,
//           ),
//         ),
//         centerTitle: true,
//         elevation: 10,
//         backgroundColor: Colors.blueAccent,
//       ),
//       body: isLoading
//           ? const Center(
//         child: CircularProgressIndicator(
//           valueColor: AlwaysStoppedAnimation<Color>(Colors.blueAccent),
//         ),
//       )
//           : familyFriends.isEmpty
//           ? const Center(
//         child: Text(
//           "No data available",
//           style: TextStyle(
//             fontSize: 18,
//             color: Colors.grey,
//           ),
//         ),
//       )
//           : ListView.builder(
//         itemCount: familyFriends.length,
//         itemBuilder: (context, index) {
//           final friend = familyFriends[index];
//           return Card(
//             elevation: 4,
//             margin: const EdgeInsets.symmetric(
//                 vertical: 8.0, horizontal: 16.0),
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(12.0),
//             ),
//             child: ListTile(
//               leading: CircleAvatar(
//                 radius: 30,
//                 backgroundImage: friend['image'] != null
//                     ? NetworkImage(friend['image'])
//                     : const AssetImage('assets/placeholder.png')
//                 as ImageProvider,
//               ),
//               title: Text(
//                 friend['relationship'],
//                 style: const TextStyle(
//                   fontWeight: FontWeight.bold,
//                   fontSize: 18,
//                 ),
//               ),
//               trailing: IconButton(
//                 icon: const Icon(Icons.delete, color: Colors.red),
//                 onPressed: () async {
//                   final sh = await SharedPreferences.getInstance();
//
//                   String url = sh.getString("url").toString();
//                   String lid = sh.getString("lid").toString();
//                   print("okkkkkkkkkkkkkkkkk");
//                   var data = await http.post(
//                       Uri.parse(url + "deletefamiliarperson"),
//                       body: {
//                         'id': friend['id'].toString(),
//                       });
//                   var jasondata = json.decode(data.body);
//                   String status = jasondata['task'].toString();
//                   if (status == "ok") {
//                     Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                             builder: (context) =>
//                                 FamilyFriendsPage()));
//                   } else {
//                     print("error");
//                   }
//                 },
//               ),
//             ),
//           );
//         },
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: () async {
//           Navigator.push(
//             context,
//             MaterialPageRoute(
//                 builder: (context) => addfamiliarperson()),
//           );
//         },
//         backgroundColor: Colors.blueAccent,
//         child: const Icon(Icons.add, color: Colors.white),
//       ),
//     );
//   }
// }





// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
// import 'addfamily_friends.dart';
//
// class FamilyFriendsPage extends StatefulWidget {
//   const FamilyFriendsPage({Key? key}) : super(key: key);
//
//   @override
//   State<FamilyFriendsPage> createState() => _FamilyFriendsPageState();
// }
//
// class _FamilyFriendsPageState extends State<FamilyFriendsPage> {
//   List<dynamic> familyFriends = [];
//   bool isLoading = true;
//
//   @override
//   void initState() {
//     super.initState();
//     _fetchFamilyFriends();
//   }
//
//   Future<void> _fetchFamilyFriends() async {
//     final pref = await SharedPreferences.getInstance();
//     String? lid = pref.getString("lid");
//     String? ip = pref.getString("url");
//
//     if (lid == null || ip == null || lid.isEmpty || ip.isEmpty) {
//       print("Invalid SharedPreferences values.");
//       setState(() {
//         isLoading = false;
//       });
//       return;
//     }
//
//     String apiUrl = "$ip/viewfamiliarperson";
//
//     try {
//       final response = await http.post(Uri.parse(apiUrl), body: {'lid': lid});
//
//       if (response.statusCode == 200) {
//         final responseData = jsonDecode(response.body);
//         if (responseData['status'] == 'ok') {
//           setState(() {
//             familyFriends = responseData['data'];
//             isLoading = false;
//           });
//         } else {
//           setState(() {
//             isLoading = false;
//           });
//           print('Error in response: ${responseData}');
//         }
//       } else {
//         setState(() {
//           isLoading = false;
//         });
//         print('Error fetching data: ${response.statusCode}');
//       }
//     } catch (e) {
//       setState(() {
//         isLoading = false;
//       });
//       print('Error: $e');
//     }
//   }
//
//   Future<void> _deleteFriend(int index) async {
//     final pref = await SharedPreferences.getInstance();
//     String? ip = pref.getString("url");
//
//     if (ip == null || ip.isEmpty) {
//       print("Invalid URL in SharedPreferences.");
//       return;
//     }
//
//     String apiUrl = "$ip/deletefamiliarperson";
//
//     try {
//       final response = await http.post(Uri.parse(apiUrl),
//           body: {'id': familyFriends[index]['id'].toString()});
//
//       if (response.statusCode == 200) {
//         final responseData = jsonDecode(response.body);
//         if (responseData['status'] == 'ok') {
//           setState(() {
//             familyFriends.removeAt(index);
//           });
//           print(" deleted successfully");
//         } else {
//           print("Failed to delete friend: ${responseData['error']}");
//         }
//       } else {
//         print('Error deleting data: ${response.statusCode}');
//       }
//     } catch (e) {
//       print('Error: $e');
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final isDarkMode = Theme.of(context).brightness == Brightness.dark;
//
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text(
//           "Family & Friends",
//           style: TextStyle(
//             fontWeight: FontWeight.bold,
//             fontSize: 24,
//           ),
//         ),
//         centerTitle: true,
//         elevation: 10,
//         backgroundColor: isDarkMode ? Colors.grey[900] : Colors.blueAccent,
//       ),
//       body: isLoading
//           ? Center(
//         child: CircularProgressIndicator(
//           valueColor: AlwaysStoppedAnimation<Color>(
//             isDarkMode ? Colors.blueAccent : Colors.blueAccent,
//           ),
//         ),
//       )
//           : familyFriends.isEmpty
//           ? Center(
//         child: Text(
//           "No data available",
//           style: TextStyle(
//             fontSize: 18,
//             color: isDarkMode ? Colors.grey[400] : Colors.grey,
//           ),
//         ),
//       )
//           : ListView.builder(
//         itemCount: familyFriends.length,
//         itemBuilder: (context, index) {
//           final friend = familyFriends[index];
//           return Card(
//             elevation: 4,
//             margin: const EdgeInsets.symmetric(
//                 vertical: 8.0, horizontal: 16.0),
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(12.0),
//             ),
//             color: isDarkMode ? Colors.grey[800] : Colors.white,
//             child: ListTile(
//               leading: CircleAvatar(
//                 radius: 30,
//                 backgroundImage: friend['image'] != null
//                     ? NetworkImage(friend['image'])
//                     : const AssetImage('assets/placeholder.png')
//                 as ImageProvider,
//               ),
//               title: Text(
//                 friend['relationship'],
//                 style: TextStyle(
//                   fontWeight: FontWeight.bold,
//                   fontSize: 18,
//                   color: isDarkMode ? Colors.white : Colors.black,
//                 ),
//               ),
//               trailing: IconButton(
//                 icon: const Icon(Icons.delete, color: Colors.red),
//                 onPressed: () async {
//                   final sh = await SharedPreferences.getInstance();
//
//                   String url = sh.getString("url").toString();
//                   String lid = sh.getString("lid").toString();
//                   print("okkkkkkkkkkkkkkkkk");
//                   var data = await http.post(
//                       Uri.parse(url + "deletefamiliarperson"),
//                       body: {
//                         'id': friend['id'].toString(),
//                       });
//                   var jasondata = json.decode(data.body);
//                   String status = jasondata['task'].toString();
//                   if (status == "ok") {
//                     Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                             builder: (context) =>
//                                 FamilyFriendsPage()));
//                   } else {
//                     print("error");
//                   }
//                 },
//               ),
//             ),
//           );
//         },
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: () async {
//           Navigator.push(
//             context,
//             MaterialPageRoute(
//                 builder: (context) => addfamiliarperson()),
//           );
//         },
//         backgroundColor: isDarkMode ? Colors.blueAccent : Colors.blueAccent,
//         child: const Icon(Icons.add, color: Colors.white),
//       ),
//     );
//   }
// }


import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'addfamily_friends.dart';

class FamilyFriendsPage extends StatefulWidget {
  const FamilyFriendsPage({Key? key}) : super(key: key);

  @override
  State<FamilyFriendsPage> createState() => _FamilyFriendsPageState();
}

class _FamilyFriendsPageState extends State<FamilyFriendsPage> {
  List<dynamic> familyFriends = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchFamilyFriends();
  }

  Future<void> _fetchFamilyFriends() async {
    final pref = await SharedPreferences.getInstance();
    String? lid = pref.getString("lid");
    String? ip = pref.getString("url");

    if (lid == null || ip == null || lid.isEmpty || ip.isEmpty) {
      print("Invalid SharedPreferences values.");
      setState(() {
        isLoading = false;
      });
      return;
    }

    String apiUrl = "$ip/viewfamiliarperson";

    try {
      final response = await http.post(Uri.parse(apiUrl), body: {'lid': lid});

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        if (responseData['status'] == 'ok') {
          setState(() {
            familyFriends = responseData['data'];
            isLoading = false;
          });
        } else {
          setState(() {
            isLoading = false;
          });
          print('Error in response: ${responseData}');
        }
      } else {
        setState(() {
          isLoading = false;
        });
        print('Error fetching data: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print('Error: $e');
    }
  }

  Future<void> _deleteFriend(int index) async {
    final pref = await SharedPreferences.getInstance();
    String? ip = pref.getString("url");

    if (ip == null || ip.isEmpty) {
      print("Invalid URL in SharedPreferences.");
      return;
    }

    String apiUrl = "$ip/deletefamiliarperson";

    try {
      final response = await http.post(Uri.parse(apiUrl),
          body: {'id': familyFriends[index]['id'].toString()});

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        if (responseData['status'] == 'ok') {
          setState(() {
            familyFriends.removeAt(index);
          });
          print(" deleted successfully");
        } else {
          print("Failed to delete friend: ${responseData['error']}");
        }
      } else {
        print('Error deleting data: ${response.statusCode}');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Family & Friends",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
        centerTitle: true,
        elevation: 10,
        backgroundColor: Colors.black,
      ),
      backgroundColor: Color(0xFF616161),
      body: isLoading
          ? Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Colors.blueAccent),
        ),
      )
          : familyFriends.isEmpty
          ? Center(
        child: Text(
          "No data available",
          style: TextStyle(
            fontSize: 18,
            color: Colors.grey[400],
          ),
        ),
      )
          : ListView.builder(
        itemCount: familyFriends.length,
        itemBuilder: (context, index) {
          final friend = familyFriends[index];
          return Card(
            elevation: 4,
            margin: const EdgeInsets.symmetric(
                vertical: 8.0, horizontal: 16.0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12.0),
            ),
            color: Colors.white,
            child: ListTile(
              leading: CircleAvatar(
                radius: 30,
                backgroundImage: friend['image'] != null
                    ? NetworkImage(friend['image'])
                    : const AssetImage('assets/placeholder.png')
                as ImageProvider,
              ),
              title: Text(
                friend['relationship'],
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: Colors.black,
                ),
              ),
              trailing: IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: () async {
                  final sh = await SharedPreferences.getInstance();
                  String url = sh.getString("url").toString();
                  var data = await http.post(
                      Uri.parse(url + "deletefamiliarperson"),
                      body: {
                        'id': friend['id'].toString(),
                      });
                  var jsonData = json.decode(data.body);
                  String status = jsonData['task'].toString();
                  if (status == "ok") {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => FamilyFriendsPage()));
                  } else {
                    print("error");
                  }
                },
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => addfamiliarperson()),
          );
        },
        backgroundColor: Colors.blueAccent,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}
