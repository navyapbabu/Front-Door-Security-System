import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:front_door_security/viewfamily_friends.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:fluttertoast/fluttertoast.dart';

class addfamiliarperson extends StatefulWidget {
  const addfamiliarperson({Key? key}) : super(key: key);

  @override
  State<addfamiliarperson> createState() => _addfamiliarpersonState();
}

class _addfamiliarpersonState extends State<addfamiliarperson> {
  TextEditingController relationshipController = TextEditingController();
  final RegExp relationshipRegExp = RegExp(r'^[A-Za-z ]{2,25}$');

  XFile? _image;

  final ImagePicker _picker = ImagePicker();

  Future<void> _imgFromCamera() async {
    try {
      XFile? image = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 50,
      );
      if (image != null) {
        setState(() {
          _image = image;
        });
      } else {
        print('No image selected from camera.');
      }
    } catch (e) {
      print('Camera error: $e');
    }
  }

  Future<void> _imgFromGallery() async {
    try {
      XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 50,
      );
      if (image != null) {
        setState(() {
          _image = image;
        });
      } else {
        print('No image selected from gallery.');
      }
    } catch (e) {
      print('Gallery error: $e');
    }
  }

  void _showPicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text('Photo Library'),
                onTap: () {
                  _imgFromGallery();
                  Navigator.of(context).pop();
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_camera),
                title: const Text('Camera'),
                onTap: () {
                  _imgFromCamera();
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _submitData() async {
    final prefs = await SharedPreferences.getInstance();
    String? url = prefs.getString("url");
    String? lid = prefs.getString("lid");

    if (url == null || lid == null) {
      print("Error: URL or lid is missing from SharedPreferences.");
      return;
    }

    if (_image == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select an image.')),
      );
      return;
    }

    try {
      var uri = Uri.parse('$url/sendfamily');
      var request = http.MultipartRequest('POST', uri);

      request.files.add(await http.MultipartFile.fromPath('image', _image!.path));
      request.fields['relationship'] = relationshipController.text;
      request.fields['lid'] = lid;

      var response = await request.send();



// Inside your function
      if (response.statusCode == 200) {
        Fluttertoast.showToast(
          msg: "Successfully Added",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.green,
          textColor: Colors.white,
        );

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => FamilyFriendsPage()),
        );
      } else {
        Fluttertoast.showToast(
          msg: "Failed to add. Try again.",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red,
          textColor: Colors.white,
        );

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => FamilyFriendsPage()),
        );
      }

    } catch (e) {
      print('Error during data submission: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Family Friends Registration"),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: GestureDetector(
                onTap: () => _showPicker(context),
                child: CircleAvatar(
                  radius: 55,
                  backgroundColor: const Color(0xffdbd8cd),
                  child: _image != null
                      ? ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: Image.file(
                      File(_image!.path),
                      width: 100,
                      height: 100,
                      fit: BoxFit.cover,
                    ),
                  )
                      : Container(
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(50),
                    ),
                    width: 100,
                    height: 100,
                    child: const Icon(
                      Icons.camera_alt,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            _buildTitle("Personal Information"),
            const SizedBox(height: 20),
            _buildTextField(
              controller: relationshipController,
              label: "Relationship",
              icon: Icons.person_outline,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your relationship with the person.';
                } else if (!relationshipRegExp.hasMatch(value)) {
                  return 'Name must be 2-25 characters long.';
                }
                return null;
              },
            ),
            const SizedBox(height: 40),
            Center(
              child: ElevatedButton(
                onPressed: _submitData,
                child: const Text("Add Person"),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTitle(String title) {
    return Text(
      title,
      style: TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.bold,
        color: Theme.of(context).colorScheme.primary,
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    FormFieldValidator<String>? validator,
    bool obscureText = false,
  }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
      ),
      obscureText: obscureText,
      validator: validator,
    );
  }
}
