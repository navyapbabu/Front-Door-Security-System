
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ViewProfile extends StatefulWidget {
  @override
  _ViewProfileState createState() => _ViewProfileState();
}

class _ViewProfileState extends State<ViewProfile> {
  Map<String, dynamic>? profileData;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchProfileData();
  }

  Future<void> fetchProfileData() async {
    final pref = await SharedPreferences.getInstance();
    String? lid = pref.getString("lid");
    String? ip = pref.getString("url");

    if (lid == null || ip == null) {
      setState(() {
        isLoading = false;
      });
      print("Error: lid or url is null in SharedPreferences");
      return;
    }

    String url = ip + "viewprofile";
    try {
      final response = await http.post(Uri.parse(url), body: {
        "lid": lid,
      });

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        if (responseData['status'] == 'ok') {
          setState(() {
            profileData = responseData['data'][0];
            isLoading = false;
          });
        } else {
          setState(() {
            isLoading = false;
          });
          print("Server error: ${responseData['status']}");
        }
      } else {
        throw Exception("Failed to connect to the server");
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print("Error: $e");
    }
  }

  void navigateToUpdateProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => UpdateProfilePage(profileData: profileData)),
    ).then((_) {
      fetchProfileData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Profile"),
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: navigateToUpdateProfile,
          ),
        ],
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : profileData == null
          ? Center(child: Text("Failed to load profile"))
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 50,
              backgroundImage: NetworkImage(profileData!['image']),
            ),
            SizedBox(height: 16),
            Text(
              profileData!['name'],
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text("Phone: ${profileData!['phonenumber']}"),
            Divider(height: 30, thickness: 1),
            buildDetailRow("Place", profileData!['place']),
            buildDetailRow("Post", profileData!['post']),
            buildDetailRow("Pin", profileData!['pin']),
          ],
        ),
      ),
    );
  }

  Widget buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontWeight: FontWeight.w600)),
          Text(value),
        ],
      ),
    );
  }
}

class UpdateProfilePage extends StatefulWidget {
  final Map<String, dynamic>? profileData;

  UpdateProfilePage({this.profileData});

  @override
  _UpdateProfilePageState createState() => _UpdateProfilePageState();
}

class _UpdateProfilePageState extends State<UpdateProfilePage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController nameController;
  late TextEditingController phoneController;
  late TextEditingController placeController;
  late TextEditingController postController;
  late TextEditingController pinController;
  XFile? _image;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.profileData?['name']);
    phoneController =
        TextEditingController(text: widget.profileData?['phonenumber']);
    placeController = TextEditingController(text: widget.profileData?['place']);
    postController = TextEditingController(text: widget.profileData?['post']);
    pinController = TextEditingController(text: widget.profileData?['pin']);
  }

  Future<void> _imgFromCamera() async {
    XFile? image = await _picker.pickImage(
        source: ImageSource.camera, imageQuality: 50);
    if (image != null) {
      setState(() {
        _image = image;
      });
    }
  }

  Future<void> _imgFromGallery() async {
    XFile? image = await _picker.pickImage(
        source: ImageSource.gallery, imageQuality: 50);
    if (image != null) {
      setState(() {
        _image = image;
      });
    }
  }

  Future<void> updateProfile() async {
    final prefs = await SharedPreferences.getInstance();
    String? url = prefs.getString("url");
    String? lid = prefs.getString("lid");
    var uri = Uri.parse('$url/updateprofile');
    print("jjjjjjjjjjjjjjjjjjjjj");
    var request = http.MultipartRequest('POST', uri);

    // Add fields
    request.fields['lid'] = prefs.getString("lid").toString();
    request.fields['name'] = nameController.text;
    request.fields['phone'] = phoneController.text;
    request.fields['place'] = placeController.text;
    request.fields['post'] = postController.text;
    request.fields['pin'] = pinController.text;

    // Add image if available
    if (_image != null) {
      request.files.add(
          await http.MultipartFile.fromPath('image', _image!.path));
    }

    var response = await request.send();

    if (response.statusCode == 200) {
      print('Profile updated successfully');
    } else {
      print('Failed to update profile');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Update Profile"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                GestureDetector(
                  onTap: () => _showPicker(context),
                  child: CircleAvatar(
                    radius: 55,
                    backgroundColor: Colors.grey[200],
                    child: _image != null
                        ? ClipRRect(
                      borderRadius: BorderRadius.circular(50),
                      child: Image.file(File(_image!.path), width: 100,
                          height: 100,
                          fit: BoxFit.cover),
                    )
                        : Icon(Icons.camera_alt, color: Colors.grey),
                  ),
                ),
                SizedBox(height: 16),
                TextFormField(
                  controller: nameController,
                  decoration: InputDecoration(labelText: "name"),
                  validator: (value) =>
                  value == null || value.isEmpty
                      ? "Name is required"
                      : null,
                ),
                TextFormField(
                  controller: phoneController,
                  decoration: InputDecoration(labelText: "Phone"),
                  keyboardType: TextInputType.phone,
                  validator: (value) =>
                  value == null || value.isEmpty
                      ? "Phone is required"
                      : null,
                ),
                TextFormField(
                  controller: placeController,
                  decoration: InputDecoration(labelText: "Place"),
                  validator: (value) =>
                  value == null || value.isEmpty
                      ? "Place is required"
                      : null,
                ),
                TextFormField(
                  controller: postController,
                  decoration: InputDecoration(labelText: "Post"),
                  validator: (value) =>
                  value == null || value.isEmpty
                      ? "Post is required"
                      : null,
                ),
                TextFormField(
                  controller: pinController,
                  decoration: InputDecoration(labelText: "Pin"),
                  keyboardType: TextInputType.number,
                  validator: (value) =>
                  value == null || value.isEmpty
                      ? "Pin is required"
                      : null,
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: updateProfile,
                  child: Text("Update"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showPicker(BuildContext context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext bc) {
          return Wrap(
            children: [
              ListTile(
                leading: Icon(Icons.photo_library),
                title: Text("Gallery"),
                onTap: () {
                  _imgFromGallery();
                  Navigator.of(context).pop();
                },
              ),
              ListTile(
                leading: Icon(Icons.photo_camera),
                title: Text("Camera"),
                onTap: () {
                  _imgFromCamera();
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        });
  }


}




// import 'dart:convert';
// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:image_picker/image_picker.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// class ViewProfile extends StatefulWidget {
//   @override
//   _ViewProfileState createState() => _ViewProfileState();
// }
//
// class _ViewProfileState extends State<ViewProfile> {
//   Map<String, dynamic>? profileData;
//   bool isLoading = true;
//
//   @override
//   void initState() {
//     super.initState();
//     fetchProfileData();
//   }
//
//   Future<void> fetchProfileData() async {
//     final pref = await SharedPreferences.getInstance();
//     String? lid = pref.getString("lid");
//     String? ip = pref.getString("url");
//
//     if (lid == null || ip == null) {
//       setState(() {
//         isLoading = false;
//       });
//       return;
//     }
//
//     String url = ip + "viewprofile";
//     try {
//       final response = await http.post(Uri.parse(url), body: {"lid": lid});
//
//       if (response.statusCode == 200) {
//         final responseData = json.decode(response.body);
//         if (responseData['status'] == 'ok') {
//           setState(() {
//             profileData = responseData['data'][0];
//             isLoading = false;
//           });
//         } else {
//           setState(() {
//             isLoading = false;
//           });
//         }
//       }
//     } catch (e) {
//       setState(() {
//         isLoading = false;
//       });
//     }
//   }
//
//   void navigateToUpdateProfile() {
//     Navigator.push(
//       context,
//       MaterialPageRoute(
//           builder: (context) => UpdateProfilePage(profileData: profileData)),
//     ).then((_) {
//       fetchProfileData();
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Theme(
//       data: ThemeData.dark().copyWith(
//         scaffoldBackgroundColor: Colors.black,
//       ),
//       child: Scaffold(
//         appBar: AppBar(
//           title: Text("Profile"),
//           actions: [
//             IconButton(
//               icon: Icon(Icons.edit),
//               onPressed: navigateToUpdateProfile,
//             ),
//           ],
//         ),
//         body: isLoading
//             ? Center(child: CircularProgressIndicator())
//             : profileData == null
//             ? Center(child: Text("Failed to load profile"))
//             : Padding(
//           padding: const EdgeInsets.all(16.0),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.center,
//             children: [
//               CircleAvatar(
//                 radius: 60,
//                 backgroundImage: NetworkImage(profileData!['image']),
//               ),
//               SizedBox(height: 16),
//               Text(
//                 profileData!['name'],
//                 style: TextStyle(
//                     fontSize: 24, fontWeight: FontWeight.bold),
//               ),
//               SizedBox(height: 8),
//               Text("Phone: ${profileData!['phonenumber']}",
//                   style: TextStyle(color: Colors.grey)),
//               Divider(height: 30, thickness: 1, color: Colors.grey),
//               buildDetailRow("Place", profileData!['place']),
//               buildDetailRow("Post", profileData!['post']),
//               buildDetailRow("Pin", profileData!['pin']),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget buildDetailRow(String label, String value) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 8.0),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Text(label,
//               style: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey)),
//           Text(value, style: TextStyle(color: Colors.white)),
//         ],
//       ),
//     );
//   }
// }
//
// class UpdateProfilePage extends StatelessWidget {
//   final Map<String, dynamic>? profileData;
//
//   UpdateProfilePage({this.profileData});
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Update Profile"),
//       ),
//       body: Center(
//         child: Text("Update Profile Form Goes Here"),
//       ),
//     );
//   }
// }
