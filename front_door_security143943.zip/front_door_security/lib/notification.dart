// import 'dart:convert';
//
//
//
// import 'package:http/http.dart' as http;
// import 'package:flutter/material.dart';
//
//
//
// import 'package:shared_preferences/shared_preferences.dart';
//
//
//
//
// class viewnotification extends StatefulWidget {
//   const viewnotification({Key? key, required this.title}) : super(key: key);
//
//   final String title;
//
//   @override
//   State<viewnotification> createState() => _viewnotification();
// }
//
//
// class _viewnotification extends State<viewnotification> {
//   int _counter = 0;
//
//   _viewnotification() {
//     view_noti();
//   }
//
//
//
//   List<String> cid_ = <String>[];
//   List<String> camera_ = <String>[];
//   List<String> image_ = <String>[];
//   List<String> date_ = <String>[];
//   List<String> status_= <String>[];
//   List<String> type_ = <String>[];
//
//
//   Future<void> view_noti() async {
//     List<String> cid = <String>[];
//     List<String> camera = <String>[];
//     List<String> image = <String>[];
//     List<String> date = <String>[];
//     List<String> sts = <String>[];
//     List<String> type = <String>[];
//
//
//
//
//     try {
//       final pref=await SharedPreferences.getInstance();
//       String lid= pref.getString("lid").toString();
//       String ip= pref.getString("url").toString();
//       // String lid= pref.getString("lid").toString();
//
//       String url=ip+"viewnotification";
//       print(url);
//       var data = await http.post(Uri.parse(url), body: {
//         'lid':lid
//       });
//
//       var jsondata = json.decode(data.body);
//       String status = jsondata['status'];
//
//       var arr = jsondata["data"];
//
//       print(arr);
//
//       print(arr.length);
//
//       for (int i = 0; i < arr.length; i++) {
//         print("okkkkkkkkkkkkkkkkkkkkkkkk");
//         cid.add(arr[i]['id'].toString());
//         camera.add(arr[i]['camera'].toString());
//         image.add(arr[i]['image'].toString());
//         date.add(arr[i]['date'].toString());
//         sts.add(arr[i]['status'].toString());
//         type.add(arr[i]['type'].toString());
//         print("ppppppppppppppppppp");
//       }
//
//       setState(() {
//         cid_ = cid;
//         camera_ = camera;
//         image_ = image;
//
//         date_ = date;
//         status_ = sts;
//         type_ = type;
//
//       });
//
//       print(cid_.length);
//       print("+++++++++++++++++++++");
//       print(status);
//     } catch (e) {
//       print("Error ------------------- " + e.toString());
//       //there is error during converting file image to base64 encoding.
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     // This method is rerun every time setState is called, for instance as done
//     // by the _incrementCounter method above.
//     //
//     // The Flutter framework has been optimized to make rerunning build methods
//     // fast, so that you can just rebuild anything that needs updating rather
//     // than having to individually change instances of widgets.
//     return Scaffold(
//         appBar: AppBar(
//             title: new Text(
//               "Notifications",
//               style: new TextStyle(color: Colors.white),
//             ),
//             leading: new IconButton(
//               icon: new Icon(Icons.arrow_back),
//               onPressed: () {
//                 Navigator.pop(context);
//                 // Navigator.pushNamed(context, '/home');
//                 // Navigator.push(context, MaterialPageRoute(builder: (context) => const  MyHomePage(title: '',)),);
//                 print("Hello");
//                 // Navigator.push(
//                 //   context,
//                 //   MaterialPageRoute(builder: (context) => ThirdScreen()),
//                 // );
//               },
//             )
//         ),
//
//         body:
//
//
//
//
//         ListView.builder(
//           physics: BouncingScrollPhysics(),
//           // padding: EdgeInsets.all(5.0),
//           // shrinkWrap: true,
//           itemCount: cid_.length,
//           itemBuilder: (BuildContext context, int index) {
//             return ListTile(
//               onLongPress: () {
//                 print("long press" + index.toString());
//               },
//               title: Padding(
//                   padding: const EdgeInsets.all(4.0),
//                   child: Column(
//                     children: [
//
//
//                       Container(
//                         width: MediaQuery. of(context). size. width,
//                         height: 300,
//                         child: Card(
//                           clipBehavior: Clip.antiAliasWithSaveLayer,
//                           child: Column(
//                             children: [
//
//
//
//
//
//
//
//                               SizedBox(height: 16,),
//                               Row(
//
//                                 children: [
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//
//                                   Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("Camera")])),
//                                   Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(camera_[index])])),
//
//                                   // Text("Place"),
//                                   // Text(place_[index])
//                                 ],
//                               ),
//                               SizedBox(height: 16,),
//                               Row(
//
//                                 children: [
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//
//                                   Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("Image")])),
//                                   Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(image_[index])])),
//
//                                   // Text("Place"),
//                                   // Text(place_[index])
//                                 ],
//                               ),
//
//
//                               SizedBox(height: 16,),
//                               Row(
//
//                                 children: [
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//
//                                   Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("Date")])),
//                                   Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(date_[index])])),
//
//                                   // Text("Place"),
//                                   // Text(place_[index])
//                                 ],
//                               ),
//                               SizedBox(height: 9,),
//                               Row(
//
//                                 children: [
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//
//                                   Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("Status")])),
//                                   Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(status_[index])])),
//
//                                   // Text("Place"),
//                                   // Text(place_[index])
//                                 ],
//                               ), SizedBox(height: 9,),
//                               Row(
//
//                                 children: [
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//
//                                   Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("Type")])),
//                                   Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(type_[index])])),
//
//                                   // Text("Place"),
//                                   // Text(place_[index])
//                                 ],
//                               ),
//                               SizedBox(height: 9,),
//
//                               Container(
//                                 padding: EdgeInsets.all(5.0),
//                                 child:   Row(
//
//                                   children: [
//
//
//                                     SizedBox(width: 10.0,),
//                                     ElevatedButton(
//                                       onPressed: () async {
//
//                                         SharedPreferences prefs = await SharedPreferences.getInstance();
//                                         prefs.setString('bid', cid_[index]);
//
//
//
//                                         // Navigator.push(
//                                         //   context,
//                                         //
//                                         //   MaterialPageRoute(builder: (context) => PaymentScreen()),
//                                         // );
//
//                                       },
//                                       child: Text('Forward to Authority'),
//                                     ),
//
//                                   ],
//                                 ),
//                               // )
//
//
//                               // Column(
//                               //     mainAxisAlignment: MainAxisAlignment.start,
//                               //     crossAxisAlignment: CrossAxisAlignment.start,
//                               //     children:[
//                               //   Text('Title'),
//                               //   Text('Subtitle')
//                               // ])
//                               )],
//                           ),
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(10.0),
//                           ),
//                           elevation: 5,
//                           margin: EdgeInsets.all(10),
//                         ),
//                       ),
//
//
//                     ],
//                   )),
//             );
//           },
//
//         )
//
//
//       // This trailing comma makes auto-formatting nicer for build methods.
//     );
//   }
//
//
//
//
//
//
// }
// //
// //
// //
// //
// //
// // import 'package:flutter/material.dart';
// // import 'package:shared_preferences/shared_preferences.dart';
// // import 'package:http/http.dart' as http;
// // import 'dart:convert';
// //
// // class ViewNotification extends StatefulWidget {
// //   const ViewNotification({Key? key}) : super(key: key);
// //
// //   @override
// //   State<ViewNotification> createState() => _ViewNotificationState();
// // }
// //
// // class _ViewNotificationState extends State<ViewNotification> {
// //   List<Map<String, String>> notifications = [];
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     viewNoti();
// //   }
// //
// //   Future<void> viewNoti() async {
// //     try {
// //       final pref = await SharedPreferences.getInstance();
// //       String lid = pref.getString("lid") ?? "";
// //       String ip = pref.getString("url") ?? "";
// //       String url = "$ip/viewnotification";
// //
// //       var data = await http.post(Uri.parse(url), body: {'lid': lid});
// //       var jsonData = json.decode(data.body);
// //
// //       if (jsonData['status'] == 'success') {
// //         var arr = jsonData["data"];
// //         setState(() {
// //           notifications = List<Map<String, String>>.from(
// //               arr.map((item) => {
// //                 'id': item['id'].toString(),
// //                 'type': item['type'].toString(),
// //                 'name': item['image'].toString(),
// //                 'folder': item['camera'].toString(),
// //                 'time': item['date'].toString(),
// //               }));
// //         });
// //       }
// //     } catch (e) {
// //       print("Error: $e");
// //     }
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       backgroundColor: Colors.black,
// //       appBar: AppBar(
// //         title: const Text("Notifications"),
// //         backgroundColor: Colors.black,
// //         leading: IconButton(
// //           icon: const Icon(Icons.arrow_back, color: Colors.white),
// //           onPressed: () => Navigator.pop(context),
// //         ),
// //       ),
// //       body: ListView.builder(
// //         itemCount: notifications.length,
// //         itemBuilder: (context, index) {
// //           var item = notifications[index];
// //           IconData iconData = Icons.insert_drive_file;
// //           if (item['type'] == 'image') {
// //             iconData = Icons.image;
// //           } else if (item['type'] == 'video') {
// //             iconData = Icons.videocam;
// //           } else if (item['type'] == 'audio') {
// //             iconData = Icons.audiotrack;
// //           }
// //
// //           return ListTile(
// //             leading: CircleAvatar(
// //               backgroundColor: Colors.purple,
// //               child: Icon(iconData, color: Colors.white),
// //             ),
// //             title: Text(
// //               "You have ${item['type'] == 'deleted' ? 'deleted' : 'added'} ${item['name']}",
// //               style: const TextStyle(color: Colors.white, fontSize: 16),
// //             ),
// //             subtitle: Text(
// //               "${item['folder']} • ${item['time']}",
// //               style: TextStyle(color: Colors.grey[400], fontSize: 14),
// //             ),
// //           );
// //         },
// //       ),
// //     );
// //   }
// // }
// //










import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class viewnotification extends StatefulWidget {
  const viewnotification({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<viewnotification> createState() => _viewnotification();
}

class _viewnotification extends State<viewnotification> {
  List<String> cid_ = <String>[];
  List<String> camera_ = <String>[];
  List<String> image_ = <String>[];
  List<String> date_ = <String>[];
  List<String> status_ = <String>[];
  List<String> type_ = <String>[];

  @override
  void initState() {
    super.initState();
    view_noti();
  }

  Future<void> view_noti() async {
    try {
      final pref = await SharedPreferences.getInstance();
      String lid = pref.getString("lid").toString();
      String ip = pref.getString("url").toString();

      String url = "$ip/viewnotification";
      var data = await http.post(Uri.parse(url), body: {
        'lid': lid
      });

      var jsondata = json.decode(data.body);
      String status = jsondata['status'];
      var arr = jsondata["data"];

      for (int i = 0; i < arr.length; i++) {
        cid_.add(arr[i]['id'].toString());
        camera_.add(arr[i]['camera'].toString());
        image_.add(arr[i]['image'].toString());
        date_.add(arr[i]['date'].toString());
        status_.add(arr[i]['status'].toString());
        type_.add(arr[i]['type'].toString());
      }

      setState(() {});
    } catch (e) {
      print("Error fetching notifications: " + e.toString());
    }
  }

  Future<void> forwardToAuthority(String cid) async {
    try {
      final pref = await SharedPreferences.getInstance();
      String lid = pref.getString("lid").toString();
      String ip = pref.getString("url").toString();
      String url = "$ip/updatestats";  // Update this to the correct endpoint if needed

      // Send the POST request to update the status to "forward to authority"
      var response = await http.post(Uri.parse(url), body: {
        'lid': lid,
        'bid': cid, // Pass the notification ID (cid) here
      });

      var responseData = json.decode(response.body);

      if (responseData['status'] == 'valid') {
        // If the status was updated successfully, show a confirmation message
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Notification forwarded to authority"))
        );
      } else {
        // Show error message if the status could not be updated
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Failed to forward to authority"))
        );
      }
    } catch (e) {
      print("Error forwarding notification: " + e.toString());
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("An error occurred while forwarding"))
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Notifications"),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: ListView.builder(
        itemCount: cid_.length,
        itemBuilder: (BuildContext context, int index) {
          return ListTile(
            title: Padding(
              padding: const EdgeInsets.all(4.0),
              child: Column(
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 300,
                    child: Card(
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      child: Column(
                        children: [
                          SizedBox(height: 16),
                          Row(
                            children: [
                              SizedBox(width: 10),
                              Text("Camera: ${camera_[index]}"),
                            ],
                          ),
                          SizedBox(height: 16),
                          Row(
                            children: [
                              SizedBox(width: 10),
                              Text("Image: ${image_[index]}"),
                            ],
                          ),
                          SizedBox(height: 16),
                          Row(
                            children: [
                              SizedBox(width: 10),
                              Text("Date: ${date_[index]}"),
                            ],
                          ),
                          SizedBox(height: 9),
                          Row(
                            children: [
                              SizedBox(width: 10),
                              Text("Status: ${status_[index]}"),
                            ],
                          ),
                          SizedBox(height: 9),
                          Row(
                            children: [
                              SizedBox(width: 10),
                              Text("Type: ${type_[index]}"),
                            ],
                          ),
                          SizedBox(height: 9),
                          Container(
                            padding: EdgeInsets.all(5.0),
                            child: Row(
                              children: [
                                SizedBox(width: 10.0),
                                ElevatedButton(
                                  onPressed: () async {
                                    // Call the method to forward the notification to authority
                                    await forwardToAuthority(cid_[index]);
                                  },
                                  child: Text('Forward to Authority'),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      elevation: 5,
                      margin: EdgeInsets.all(10),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
