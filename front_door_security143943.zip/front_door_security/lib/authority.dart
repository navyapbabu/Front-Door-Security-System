
import 'package:flutter/material.dart';
import 'package:front_door_security/authority/view_user.dart';
import 'package:front_door_security/authority/view_criminals.dart';
import 'package:front_door_security/feedback.dart';
import 'package:front_door_security/userprofile.dart';
import 'package:front_door_security/viewauthority.dart';
import 'package:front_door_security/viewauthorityprofile.dart';
import 'package:front_door_security/viewfamily_friends.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: authorityhome(),
    );
  }
}

class authorityhome extends StatefulWidget {
  @override
  _authorityhomeState createState() => _authorityhomeState();
}

class _authorityhomeState extends State<authorityhome> {
  final List<Map<String, dynamic>> premises = [
    // {'icon': Icons.home, 'label': 'Home', 'page': HomeScreen()},
    {'icon': Icons.person, 'label': 'Profile', 'page': authorityprofile()},
    {'icon': Icons.group, 'label': 'View Users', 'page': ViewUsersPage()},
    // {'icon': Icons.chat, 'label': 'Chat with User ', 'page': viewROUTEUSER()},
    {'icon': Icons.security, 'label': 'Manage Criminals', 'page': ViewCriminalsPage()},
    {'icon': Icons.notifications, 'label': 'View Notifications', 'page': NotificationScreen()},
    {'icon': Icons.report, 'label': 'View Criminal Notifications', 'page': ComplaintScreen()},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade700,
      appBar: AppBar(
        backgroundColor: Colors.grey.shade700,
        title: Text('Welcome', style: TextStyle(color: Colors.white)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Select an option', style: TextStyle(color: Colors.white70)),
            SizedBox(height: 16),
            Expanded(
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.5,
                ),
                itemCount: premises.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => premises[index]['page'],
                        ),
                      );
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.black87,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(premises[index]['icon'], color: Colors.white, size: 30),
                          SizedBox(height: 8),
                          Text(
                            premises[index]['label'],
                            style: TextStyle(color: Colors.white, fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Individual screens for each section

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Home")),
      body: Center(child: Text("Welcome to Home Screen")),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Profile")),
      body: Center(child: Text("Profile Page")),
    );
  }
}

class FamilyFriendsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Family/Friends")),
      body: Center(child: Text("Family & Friends Page")),
    );
  }
}

class ViewAuthorityScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("View Authority")),
      body: Center(child: Text("View Authority Page")),
    );
  }
}

class FeedbackScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Feedback")),
      body: Center(child: Text("Feedback Page")),
    );
  }
}

class NotificationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Notification")),
      body: Center(child: Text("Notification Page")),
    );
  }
}

class ComplaintScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Complaint")),
      body: Center(child: Text("Complaint Page")),
    );
  }
}
