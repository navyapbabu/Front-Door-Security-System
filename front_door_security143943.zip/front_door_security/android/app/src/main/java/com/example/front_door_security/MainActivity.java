package com.example.front_door_security;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
